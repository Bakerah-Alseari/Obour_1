import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'firebase_mocks.dart'; // Make sure you have mocks for FirebaseAuth, User, FirebaseFirestore, etc.

void main() {
  late MockFirebaseAuth mockAuth;
  late MockUser mockUser;
  late MockFirebaseFirestore mockFirestore;
  late MockCollectionReference mockPatientsCollection;
  late MockDocumentReference mockUserDoc;
  late MockCollectionReference mockContactPeerCollection;

  setUp(() {
    mockAuth = MockFirebaseAuth();
    mockUser = MockUser();
    mockFirestore = MockFirebaseFirestore();
    mockPatientsCollection = MockCollectionReference();
    mockUserDoc = MockDocumentReference();
    mockContactPeerCollection = MockCollectionReference();

    // Setup FirebaseAuth mock
    when(() => mockAuth.currentUser).thenReturn(mockUser);
    when(() => mockUser.uid).thenReturn('test-user-id');

    // Setup Firestore mock
    when(() => mockFirestore.collection('Patient')).thenReturn(mockPatientsCollection);
    when(() => mockPatientsCollection.doc('test-user-id')).thenReturn(mockUserDoc);
    when(() => mockUserDoc.collection('contactPeer')).thenReturn(mockContactPeerCollection);
  });

  test('Save contacts to Firestore', () async {
    final contacts = [
      {'name': 'Ali', 'phone': '0555555555'},
      {'name': 'Sara', 'phone': '966123456789'}
    ];
    // Mock .add() behavior
    for (var contact in contacts) {
      when(() => mockContactPeerCollection.add({
        'PeerName': contact['name'],
        'PeerPhoneNumber': contact['phone'],
      })).thenAnswer((_) async {
        print('✅ Firestore add called with: $contact');
        return MockDocumentReference();
      });
    }
    // Simulate saving each contact
    for (var contact in contacts) {
      await mockFirestore
          .collection('Patient')
          .doc('test-user-id')
          .collection('contactPeer')
          .add({
        'PeerName': contact['name'],
        'PeerPhoneNumber': contact['phone'],
      });
    }
    // Verify each call
    for (var contact in contacts) {
      verify(() => mockContactPeerCollection.add({
        'PeerName': contact['name'],
        'PeerPhoneNumber': contact['phone'],
      })).called(1);
    }
    print('✅ All contacts saved to Firestore successfully.');
  });


  test('Do not save contact with invalid phone number format', () async {
    final invalidContact = {'name': 'Invalid User', 'phone': '123abc'};

    bool isValidPhoneNumber(String phone) {
      final regex = RegExp(r'^\d{9,15}$');
      return regex.hasMatch(phone);
    }
    if (!isValidPhoneNumber(invalidContact['phone']!)) {
      print('❌ Invalid phone number format: ${invalidContact['phone']}');
    } else {
      // This should NOT be executed in this test
      await mockFirestore
          .collection('Patient')
          .doc('test-user-id')
          .collection('contactPeer')
          .add({
        'PeerName': invalidContact['name'],
        'PeerPhoneNumber': invalidContact['phone'],
      });
    }
    verifyNever(() => mockContactPeerCollection.add(any()));
  });




}