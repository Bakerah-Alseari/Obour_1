import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'firebase_mocks.dart'; // Your mock classes here

void main() {
  late MockFirebaseAuth mockAuth;
  late MockUser mockUser;
  late MockFirebaseFirestore mockFirestore;
  late MockCollectionReference mockPatientsCollection;
  late MockDocumentReference mockUserDoc;
  late MockCollectionReference mockActivatesCollection;
  late MockDocumentReference mockActivityDoc;
  late MockCollectionReference mockAvailabilityCollection;

  setUp(() {
    mockAuth = MockFirebaseAuth();
    mockUser = MockUser();
    mockFirestore = MockFirebaseFirestore();
    mockPatientsCollection = MockCollectionReference();
    mockUserDoc = MockDocumentReference();
    mockActivatesCollection = MockCollectionReference();
    mockActivityDoc = MockDocumentReference();
    mockAvailabilityCollection = MockCollectionReference();

    // Auth
    when(() => mockAuth.currentUser).thenReturn(mockUser);
    when(() => mockUser.uid).thenReturn('test-user-id');

    // Firestore base structure
    when(() => mockFirestore.collection('Patient')).thenReturn(mockPatientsCollection);
    when(() => mockPatientsCollection.doc('test-user-id')).thenReturn(mockUserDoc);
    when(() => mockUserDoc.collection('Activates')).thenReturn(mockActivatesCollection);
    when(() => mockActivatesCollection.doc(any())).thenReturn(mockActivityDoc);
    when(() => mockUserDoc.collection('Availability')).thenReturn(mockAvailabilityCollection);
  });

  test('Select and save activity to Firestore', () async {
    final activityData = {
      'ActivityName': 'رياضة',
      'ActivityDate': '2025-05-01',
      'ActivityStatus': false,
    };

    when(() => mockActivityDoc.set(activityData)).thenAnswer((_) async {
      print('✅ Activity saved: $activityData');
    });

    await mockFirestore
        .collection('Patient')
        .doc('test-user-id')
        .collection('Activates')
        .doc('activity1')
        .set(activityData);

    verify(() => mockActivityDoc.set(activityData)).called(1);
  });

  test('Save priority for each activity', () async {
    final priorityData = {
      'Priority': 1,
    };

    when(() => mockActivityDoc.update(priorityData)).thenAnswer((_) async {
      print('✅ Priority updated: $priorityData');
    });

    await mockFirestore
        .collection('Patient')
        .doc('test-user-id')
        .collection('Activates')
        .doc('activity1')
        .update(priorityData);

    verify(() => mockActivityDoc.update(priorityData)).called(1);
  });

  test('Save free time availability (day and time)', () async {
    final day = 'الأحد';
    final availabilityData = {
      'start': '07:00',
      'end': '20:00',
    };

    when(() => mockAvailabilityCollection.doc(day)).thenReturn(mockActivityDoc);
    when(() => mockActivityDoc.set(availabilityData)).thenAnswer((_) async {
      print('✅ Availability saved for $day: $availabilityData');
    });

    await mockFirestore
        .collection('Patient')
        .doc('test-user-id')
        .collection('Availability')
        .doc(day)
        .set(availabilityData);

    verify(() => mockActivityDoc.set(availabilityData)).called(1);
  });

}