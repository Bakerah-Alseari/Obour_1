import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'firebase_mocks.dart';



void main() {
  late MockFirebaseAuth mockAuth;
  late MockUserCredential mockUserCredential;
  late MockUser mockUser;
  late MockFirebaseFirestore mockFirestore;
  late MockCollectionReference mockUsersCollection;
  late MockDocumentReference mockUserDoc;

  setUp(() {
    mockAuth = MockFirebaseAuth();
    mockUserCredential = MockUserCredential();
    mockUser = MockUser();
    mockFirestore = MockFirebaseFirestore();
    mockUsersCollection = MockCollectionReference();
    mockUserDoc = MockDocumentReference();

    // Auth mocks
    when(() => mockAuth.createUserWithEmailAndPassword(
      email: any(named: 'email'),
      password: any(named: 'password'),
    )).thenAnswer((_) async => mockUserCredential);

    when(() => mockUserCredential.user).thenReturn(mockUser);
    when(() => mockUser.uid).thenReturn('new-user-uid');

    // Firestore mocks
    when(() => mockFirestore.collection('Patient')).thenReturn(mockUsersCollection);
    when(() => mockUsersCollection.doc('new-user-uid')).thenReturn(mockUserDoc);
  });


  test('Sign up and save user profile to Firestore', () async {
    const email = 'lolo1@gmail.com';
    const password = '123456789';
    const name = 'lolo1';
    const phone = '0566713106';
    const birthDate = '2002-5-5';
    print('🟡 Starting sign up test...');

    // Step 1: FirebaseAuth signup
    final credential = await mockAuth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    );
    final uid = credential.user!.uid;
    print('✅ FirebaseAuth.createUserWithEmailAndPassword called: UID = $uid');

    // Step 2: Firestore set user profile
    final userData = {
      'name': name,
      'email': email,
      'password': password,
      'phone': phone,
      'birthDate': birthDate,
      'createdAt': DateTime(2025, 4, 15, 21, 52, 54), // or DateTime.now()
    };
    when(() => mockUserDoc.set(any())).thenAnswer((_) async {
      print('✅ Firestore user profile saved.');
    });

    await mockFirestore.collection('Patient').doc(uid).set({
      'name': name,
      'email': email,
      'password': password,
      'phone': phone,
      'birthDate': birthDate,
      'createdAt': DateTime.now(), // typically captured at runtime
    });
    verify(() => mockUserDoc.set(any())).called(1);
    print('✅ Sign up and Firestore user profile test passed.\n');
  });


  test('❌ Signup fails when email already exists', () async {
    const email = 'duplicate@example.com';
    const password = '123456789';

    when(() => mockAuth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    )).thenThrow(FirebaseAuthException(code: 'email-already-in-use'));

    try {
      await mockAuth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      fail('Expected FirebaseAuthException for email-already-in-use');
    } on FirebaseAuthException catch (e) {
      expect(e.code, 'email-already-in-use');
      print('✅ Detected email already in use during signup.');
    }
  });


  test('❌ Login fails with wrong password', () async {
    const email = 'user@example.com';
    const wrongPassword = 'wrongpass123';

    when(() => mockAuth.signInWithEmailAndPassword(
      email: email,
      password: wrongPassword,
    )).thenThrow(FirebaseAuthException(code: 'wrong-password'));

    try {
      await mockAuth.signInWithEmailAndPassword(
        email: email,
        password: wrongPassword,
      );
      fail('Expected FirebaseAuthException for wrong-password');
    } on FirebaseAuthException catch (e) {
      expect(e.code, 'wrong-password');
      print('✅ Detected wrong password during login.');
    }
  });

  test('❌ Phone number format invalid (manual validation)', () {
    final invalidPhones = ['12345', '0712312312', '5123456789', '', '966123'];
    final validPhones = ['0566713106', '96656713106'];

    bool isValid(String phone) {
      return (phone.startsWith('05') || phone.startsWith('966')) && phone.length >= 10;
    }

    for (var phone in invalidPhones) {
      expect(isValid(phone), false, reason: 'Expected invalid: $phone');
      print('✅ Detected invalid phone: $phone');
    }

    for (var phone in validPhones) {
      expect(isValid(phone), true, reason: 'Expected valid: $phone');
      print('✅ Detected valid phone: $phone');
    }
  });


}