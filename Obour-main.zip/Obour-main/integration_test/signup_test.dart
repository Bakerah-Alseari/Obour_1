import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:obour_1/main.dart' as app;
import 'package:flutter/material.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('User signs up successfully and navigates to next screen', (WidgetTester tester) async {
    app.main(); // start your app
    await tester.pumpAndSettle();

    // Enter test data
    await tester.enterText(find.byKey(const Key('name_field')), 'Test User');
    await tester.enterText(find.byKey(const Key('email_field')), 'testuser@example.com');
    await tester.enterText(find.byKey(const Key('password_field')), 'password123');
    await tester.enterText(find.byKey(const Key('phone_field')), '0555555555');
    await tester.enterText(find.byKey(const Key('birthdate_field')), '2000-01-01');

    // Tap continue button
    await tester.tap(find.byKey(const Key('continue_button')));
    await tester.pumpAndSettle();

    // Expect navigation to next screen
    expect(find.text('اختر الأنشطة المفضلة'), findsOneWidget); // Adjust text as needed
  });
}
