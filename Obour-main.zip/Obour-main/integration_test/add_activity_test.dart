import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:obour_1/main.dart' as app;
import 'package:flutter/material.dart';

Future<void> waitForActivityByKey(WidgetTester tester, String keyValue,
    {Duration timeout = const Duration(seconds: 10)}) async {
  final endTime = DateTime.now().add(timeout);
  while (DateTime.now().isBefore(endTime)) {
    await tester.pump(const Duration(milliseconds: 500));
    final found = find.byKey(Key(keyValue));
    if (found.evaluate().isNotEmpty) return;
  }
  throw Exception('❌ Widget with Key("$keyValue") not found in UI within timeout.');
}

Future<User> waitForFirebaseUser({Duration timeout = const Duration(seconds: 10)}) async {
  final endTime = DateTime.now().add(timeout);
  while (DateTime.now().isBefore(endTime)) {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) return user;
    await Future.delayed(const Duration(milliseconds: 500));
  }
  throw Exception('❌ FirebaseAuth.currentUser is still null after waiting.');
}

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('Add activity on this and upcoming Sundays, and verify it appears on HomeScreen', (tester) async {
    // ✅ Initialize Firebase and run app
    await Firebase.initializeApp();
    app.main();
    await tester.pumpAndSettle(const Duration(seconds: 10));

    // 🟠 Tap "التالي" on launch screen
    final launchButton = find.text('التالي');
    expect(launchButton, findsOneWidget);
    await tester.tap(launchButton);
    await tester.pumpAndSettle(const Duration(seconds: 3));
    print("🟠 Pressed 'التالي'");

    // 🟠 Tap "قم بالتسجيل الدخول" on onboarding screen
    final loginLink = find.byWidgetPredicate(
          (widget) => widget is RichText && widget.text.toPlainText().contains('قم بالتسجيل الدخول'),
    );
    expect(loginLink, findsOneWidget);
    await tester.tap(loginLink);
    await tester.pumpAndSettle(const Duration(seconds: 3));
    print("🟠 Pressed 'قم بالتسجيل الدخول'");

    // 🔐 Fill login fields
    const testEmail = 'sama@gmail.com';
    const testPassword = '123456789';

    final emailField = find.byKey(const Key('email_field'));
    final passwordField = find.byKey(const Key('password_field'));

    expect(emailField, findsOneWidget);
    await tester.enterText(emailField, testEmail);

    expect(passwordField, findsOneWidget);
    await tester.enterText(passwordField, testPassword);

    // 🟠 Tap login button
    final loginButton = find.byKey(const Key('login_button'));
    expect(loginButton, findsOneWidget);
    await tester.tap(loginButton);
    await tester.pumpAndSettle(const Duration(seconds: 5));
    print("🟠 Pressed 'تسجيل الدخول'");

    // ✅ Wait for Firebase user to be available after login
    final user = await tester.runAsync(waitForFirebaseUser);
    final uid = user!.uid;
    final email = user.email ?? 'no-email-available';
    print('✅ User is signed in with UID: $uid, Email: $email');

    // 📝 Add test activity to Firestore for this Sunday and upcoming Sundays
    final now = DateTime.now();
    final int daysSinceSunday = now.weekday % 7; // Sunday = 0
    final thisSunday = now.subtract(Duration(days: daysSinceSunday));
    final thisSundayMidnight = DateTime(thisSunday.year, thisSunday.month, thisSunday.day);

    // Add for this Sunday + next 2 Sundays
    final upcomingSundays = List.generate(3, (i) {
      final nextSunday = thisSunday.add(Duration(days: 7 * i));
      return DateTime(nextSunday.year, nextSunday.month, nextSunday.day);
    });

    final firestore = FirebaseFirestore.instance;
    final activityRef = firestore
        .collection('Patient')
        .doc(uid)
        .collection('Activates')
        .doc('integration-activity');

    await tester.runAsync(() async {
      await activityRef.set({'ActivityName': 'النشاط'});

      for (int i = 0; i < upcomingSundays.length; i++) {
        await activityRef
            .collection('ScheduledDates')
            .doc('auto-test-${i + 1}')
            .set({
          'scheduledDate': Timestamp.fromDate(upcomingSundays[i]),
          'startTime': '09:00',
          'endTime': '10:00',
          'isCompleted': false,
        });
      }
    });

    print('✅ Activity added to Firestore for this and upcoming Sundays');

    // 🔄 Wait for UI to show the new activity
    await tester.pumpAndSettle(const Duration(seconds: 5));

    // 🗓 Tap on Sunday
    final dayBox = find.byKey(Key('الأحد'));
    expect(dayBox, findsOneWidget);
    await tester.tap(dayBox);
    await tester.pumpAndSettle();

    // ✅ Wait for activity widget with Key('النشاط')
    await waitForActivityByKey(tester, 'النشاط');
    expect(find.byKey(Key('النشاط')), findsOneWidget);
    print('✅ Activity is visible on HomeScreen with key "النشاط"');
  });
}
