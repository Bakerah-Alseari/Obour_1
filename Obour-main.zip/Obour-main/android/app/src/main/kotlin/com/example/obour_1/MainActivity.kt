package com.example.obour_1

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.util.Log
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val SMS_CHANNEL = "com.example.sms"
    private val ALARM_CHANNEL = "com.obour/alarm_permission"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        Log.d("MainActivity", "Native channels configured")

        // SMS channel
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, SMS_CHANNEL)
            .setMethodCallHandler { call, result ->
                if (call.method == "sendSms") {
                    val phone = call.argument<String>("phone")
                    val message = call.argument<String>("message")

                    if (phone != null && message != null) {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW)
                            intent.data = Uri.parse("sms:$phone")
                            intent.putExtra("sms_body", message)
                            startActivity(intent)
                            result.success("SMS intent launched")
                        } catch (e: Exception) {
                            result.error("FAILED_TO_LAUNCH", e.message, null)
                        }
                    } else {
                        result.error("INVALID_ARGUMENT", "Phone or message is missing", null)
                    }
                } else {
                    result.notImplemented()
                }
            }

        // Alarm permission channel
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, ALARM_CHANNEL)
            .setMethodCallHandler { call, result ->
                if (call.method == "isExactAlarmGranted") {
                    val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        result.success(alarmManager.canScheduleExactAlarms())
                    } else {
                        result.success(true) // not required before Android 12
                    }
                } else {
                    result.notImplemented()
                }
            }
    }
}
