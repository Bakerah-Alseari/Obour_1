import 'package:flutter/material.dart';
import 'profile.dart';
import 'badges.dart';
import 'activ_home_screen.dart';
import 'media.dart';
import 'peers_contact.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class QuotesScreen extends StatefulWidget {
  const QuotesScreen({super.key});

  @override
  State<QuotesScreen> createState() => _QuotesScreen();
}

class _QuotesScreen extends State<QuotesScreen>{
  int _selectedIndex = 0; // Track selected tab

  void _onItemTapped(int index) {
    late Widget screen;

    switch (index) {
      case 0:
        screen = const HomeScreen(); // activity page
        break;
      case 1:
        screen = const Badges();
        break;
      case 2:
        screen = const Media();
        break;
      case 3:
        screen = const peersContact(); // contact
        break;
      case 4:
        screen = const Profile();
        break;
      default:
        break;
    }

    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => screen),
    );
  }

  // ✅ Navigation Icon Widget (Handles Selection & Image Display)
  Widget navIcon(String imagePath, int index) {
    return GestureDetector(
      onTap: () => _onItemTapped(index), // Navigate on tap
      child: Image.asset(
        imagePath,
        width: 30,
        height: 30,
        color: _selectedIndex == index ? Colors.brown : Colors.black45, // Highlight selected tab
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCEFE6),
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(context),
            const SizedBox(height: 10),
            Expanded(
              child: StreamBuilder<QuerySnapshot>( //live to the Firestore collection
                stream: FirebaseFirestore.instance.collection('EducationalContent').snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return const Center(child: Text('لا توجد معلومات حالياً', style: TextStyle(fontSize: 18)));
                  }

                  final documents = snapshot.data!.docs;

                  return ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: documents.length,
                    itemBuilder: (context, index) {
                      final data = documents[index].data() as Map<String, dynamic>;
                      final title = data['title'] ?? 'بدون عنوان';
                      final description = data['description'] ?? 'لا يوجد شرح';

                      return Container(
                        margin: const EdgeInsets.only(bottom: 16),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(color: Colors.black12, blurRadius: 6, spreadRadius: 3),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              title,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF632B00),
                              ),
                              textAlign: TextAlign.right,
                            ),
                            const SizedBox(height: 8),
                            Text(
                              description,
                              style: const TextStyle(fontSize: 16, color: Colors.black87),
                              textAlign: TextAlign.right,
                            ),
                          ],
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),

      // ✅ Custom Bottom Navigation Bar
      bottomNavigationBar: SafeArea(
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(
                color: Colors.black12,
                blurRadius: 5,
                spreadRadius: 6,
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              navIcon('assets/images/calender.png', 0),
              navIcon('assets/images/Badge.png', 1),
              navIcon('assets/images/Media.png', 2),
              navIcon('assets/images/Contact.png', 3),
              navIcon('assets/images/Profile.png', 4),
            ],
          ),
        ),
      ),
    );
  }
}

Widget _buildHeader(BuildContext context) {
  return SizedBox(
    height: 250, // Adjust height as needed
    child: Stack(
      children: [
        Positioned(
          child: Image.asset(
            'assets/images/Bg.png',
            fit: BoxFit.fill,
            width: double.infinity,
          ),
        ),

        // ✅ Custom Back Button (Top Right)
        Positioned(
          top: 30,
          right: 20,
          child: GestureDetector(
            onTap: () {
              Navigator.pop(context);
            },
            child: Image.asset(
              "assets/images/backOrange.png",
              width: 40,
              height: 40,
            ),
          ),
        ),



        //  Properly Aligned Row for Text & Image
        Positioned(
          left: 20,
          right: 70,
          top: 70, //  Adjusts row position properly
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceBetween, //  Ensures proper spacing
            children: [
              //  Text Section (Left Side)
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start, //  Aligns text to the left
                  mainAxisSize: MainAxisSize.min, //  Prevents unwanted stretching
                  children: [
                    const Text(
                      "معلومات نصية",
                      maxLines: 1, //  Prevents multi-line wrapping
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 30, //  Bigger title
                        color: Color(0xFF632B00),
                        fontWeight: FontWeight.bold,
                        fontFamily: "Inter",
                      ),
                    ),
                    const SizedBox(height: 5), //  Better spacing
                    const Text(
                      "وسّع مدارِكك",
                      style: TextStyle(
                        fontSize: 20,
                        color: Color(0xFF632B00),
                        fontFamily: "Inter",
                      ),
                    ),
                  ],
                ),
              ),

              //  Bigger YouTube Icon on Right
              SizedBox(
                width: 190, //  Ensures the image stays right
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Image.asset(
                    'assets/images/QouteOrange.png',
                    width: 150, //  Adjusted size for balance
                    height: 150,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );
}
