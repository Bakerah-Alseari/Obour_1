import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'activ_history.dart';
import 'activ_generate_weekly_plan.dart';
import 'signup_activity_selection.dart';
import 'chatgpt_service.dart';



class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedMood = -1; // selected mood, -1 = no mood
  DateTime selectedDate = DateTime.now();
  DateTime displayedWeekStartDate = _findBeginningOfWeek(DateTime.now());
  final ScrollController _scrollController = ScrollController();
  final List<String> emotions = ["Wonderful", "Good", "Average", "Bad", "Worst"]; // List of mood options

  static DateTime _findBeginningOfWeek(DateTime date) {
    return date.subtract(Duration(days: date.weekday % 7));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCEFE6),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              _buildHeader(),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    _buildMoodSelector(),
                    const Divider(color: Colors.grey, thickness: 1.2, indent: 16, endIndent: 16),
                    const SizedBox(height: 10),
                    _buildTodayActivitiesHeader(),
                    const SizedBox(height: 8),
                    _buildWeekDaysSelector(),
                    const SizedBox(height: 15),
                    _buildActivitiesList(),
                    const SizedBox(height: 20),
                  ],
                ),

              ),
            ],
          ),
        ),
      ),
    );
  }


  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      height: 270,
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage('assets/images/Bg.png'),
          fit: BoxFit.cover,
        ),
      ),
      child: Stack(
        children: [
          Positioned(
            top: 16,
            right: 16,
            child: GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ActivitiesHistory()),
                );
              },
              child: Image.asset(
                'assets/images/bell.png',
                width: 30,
                height: 30,
              ),
            ),
          ),
          Positioned(
            top: 80,
            left: 20,
            right: 20,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(
                  "خطوة للأمام",
                  style: TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.bold,
                    color: Colors.brown,
                    fontFamily: "Inter",
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  "استمر في نشاطاتك اليومية.\nالنجاح قريباً!",
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.brown,
                    fontFamily: "assets/fonts/Roboto-Regular.ttf",
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            top: 40,
            right: 90,
            child: Image.asset(
              'assets/images/growth.png',
              width: 455.5,
              height: 260,
            ),
          ),
        ],
      ),
    );
  }

  // building the UI for selecting the mood
  Widget _buildMoodSelector() {
    return Align(
      alignment: Alignment.centerRight, // arabic layout
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'كيف تشعر اليوم؟',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal, // scrolling mood bar horizontally
            child: Row(
              children: List.generate(5, (index) { // Create 5 mood icons based on emotions
                return GestureDetector(
                  onTap: () => _onMoodSelected(index), // tapping the mood
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    margin: EdgeInsets.symmetric(horizontal: 4, vertical: _selectedMood == index ? 0 : 10), // add 10 pixels vertically if a mood is selected
                    width: _selectedMood == index ? 80 : 70,
                    height: _selectedMood == index ? 80 : 70,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        if (_selectedMood == index)
                          Container(
                            width: 65,
                            height: 65,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.yellow.withAlpha(153),
                                  blurRadius: 15,
                                  spreadRadius: 5,
                                ),
                              ],
                            ),
                          ),
                        Image.asset(
                          'assets/images/mood_$index.png', // emojis
                          width: 43,
                          height: 43,
                        ),
                      ],
                    ),
                  ),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTodayActivitiesHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const Text(
          "أنشطة اليوم",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        GestureDetector(
          onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) => const FavoriteActivitiesScreen()));
          },
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                "تعديل الخطة",
                style: TextStyle(fontSize: 15, color: Color(0xFF373A40)),
              ),
              const SizedBox(width: 9),
              Image.asset(
                'assets/images/Edit.png',
                width: 14,
                height: 14,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildWeekDaysSelector() {
    return SizedBox(
      height: 70,
      child: Row(
        children: [
          IconButton(
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(),
            icon: Image.asset('assets/images/arowrghit.png', width: 18, height: 18),
            onPressed: _goToPreviousWeek,
          ),
          const SizedBox(width: 0),
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              scrollDirection: Axis.horizontal,
              itemCount: 7,
              itemBuilder: (context, index) {
                final date = displayedWeekStartDate.add(Duration(days: index));
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      selectedDate = date;
                    });
                  },
                  child: dateBox(
                    DateFormat.E('ar').format(date),
                    DateFormat.d().format(date),
                    isSameDay(date, selectedDate),
                  ),
                );
              },
            ),
          ),
          const SizedBox(width: 0),
          IconButton(
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(),
            icon: Image.asset('assets/images/arowleft.png', width: 18, height: 18),
            onPressed: _goToNextWeek,
          ),
        ],
      ),
    );
  }

  Widget _buildActivitiesList() {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: getActivitiesForSelectedDate(selectedDate),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          return const Center(child: Text('حدث خطأ أثناء تحميل الأنشطة'));
        } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return const Center(child: Text('لا توجد أنشطة لهذا اليوم'));
        }

        final activities = snapshot.data!;

        return Column(
          children: activities.map((activity) => activityCard(activity)).toList(),
        );
      },
    );
  }

  // tapping a mood
  void _onMoodSelected(int index) async {
    try {
      setState(() {
        _selectedMood = index; // UI updated to show which mood is selected
      });

      // loading spinner when fetching data
      showDialog(
        context: context,
        barrierDismissible: false, // no dismissing the dialog by tapping outside it.
        builder: (context) => const AlertDialog(
          backgroundColor: Color(0xFFFCEFE6),
          content: SizedBox(height: 80, child: Center(child: CircularProgressIndicator())), // loading spinner
        ),
      );

      // fetch the user id from DB
      final uid = FirebaseAuth.instance.currentUser?.uid;

      // store the selected motivation qoute types in a list
      List<String> quoteTypes = [];
      if (uid != null) {
        // Fetch all documents inside the Quotes
        final snapshot = await FirebaseFirestore.instance
            .collection("Patient")
            .doc(uid)
            .collection("Quotes")
            .get();

        for (var doc in snapshot.docs) { // Loop through each document
          final data = doc.data();
          if (data["QuoteType"] != null) {
            quoteTypes.add(data["QuoteType"]); // Add QuoteType value to quoteTypes list.
          }
        }
      }

      if (quoteTypes.isEmpty) {
        quoteTypes = ["نصائح"]; // make it a default is list is empty make it advices
      }

      // Call ChatGPT to generate a personalized quote based on mood and quote types
      final quote = await ChatGPTService.generateQuote(emotions[index], quoteTypes);

      Navigator.pop(context); // Close the loading spinner

      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          backgroundColor: const Color(0xFFFCEFE6),
          contentPadding: const EdgeInsets.fromLTRB(20, 20, 20, 30),
          content: Stack(
            children: [
              Positioned(
                top: 0,
                right: 0,
                child: IconButton(
                  icon: const Icon(Icons.close, color: Colors.brown),
                  onPressed: () => Navigator.pop(context),
                ),
              ),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const SizedBox(height: 40),
                  Text(
                    quote,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 18,
                      color: Colors.brown,
                      fontWeight: FontWeight.w800,
                      fontFamily: 'Inter',
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    } catch (e) {
      print('❌ Error generating quote: $e');
      Navigator.pop(context);
    }
  }

  void _goToPreviousWeek() async {
    DateTime lastWeekStart = _findBeginningOfWeek(DateTime.now()).subtract(const Duration(days: 7));
    if (displayedWeekStartDate.isAfter(lastWeekStart)) {
      setState(() {
        displayedWeekStartDate = displayedWeekStartDate.subtract(const Duration(days: 7));
        selectedDate = displayedWeekStartDate;
      });
      await generateWeeklySchedule(displayedWeekStartDate);
    }
  }

  void _goToNextWeek() async {
    DateTime nextWeekStart = _findBeginningOfWeek(DateTime.now()).add(const Duration(days: 7));
    if (displayedWeekStartDate.isBefore(nextWeekStart)) {
      setState(() {
        displayedWeekStartDate = displayedWeekStartDate.add(const Duration(days: 7));
        selectedDate = displayedWeekStartDate;
      });
      await generateWeeklySchedule(displayedWeekStartDate);
    }
  }

  Future<List<Map<String, dynamic>>> getActivitiesForSelectedDate(DateTime selectedDate) async {
    final userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId == null) return [];

    final firestore = FirebaseFirestore.instance;
    final activities = <Map<String, dynamic>>[];

    final activatesSnapshot = await firestore
        .collection('Patient')
        .doc(userId)
        .collection('Activates')
        .get();

    for (var activityDoc in activatesSnapshot.docs) {
      final activityData = activityDoc.data();
      final activityName = activityData['ActivityName'] ?? 'نشاط بدون اسم';
      final activityId = activityDoc.id;

      final scheduledSnapshot = await firestore
          .collection('Patient')
          .doc(userId)
          .collection('Activates')
          .doc(activityId)
          .collection('ScheduledDates')
          .get();

      for (var scheduleDoc in scheduledSnapshot.docs) {
        final scheduleData = scheduleDoc.data();
        if (scheduleData['scheduledDate'] == null || scheduleData['startTime'] == null) continue;

        final scheduledDate = (scheduleData['scheduledDate'] as Timestamp).toDate();

        if (isSameDay(scheduledDate, selectedDate)) {
          activities.add({
            'activityName': activityName,
            'startTime': scheduleData['startTime'],
            'endTime': scheduleData['endTime'] ?? '',
            'isCompleted': scheduleData['isCompleted'] ?? false,
            'activityDocId': activityId,
            'scheduledDateId': scheduleDoc.id,
          });
        }
      }
    }

    activities.sort((a, b) => _parseTime(a['startTime']).compareTo(_parseTime(b['startTime'])));

    return activities;
  }

  bool isSameDay(DateTime d1, DateTime d2) {
    return d1.year == d2.year && d1.month == d2.month && d1.day == d2.day;
  }

  DateTime _parseTime(String timeString) {
    final parts = timeString.split(':');
    return DateTime(0, 1, 1, int.parse(parts[0]), int.parse(parts[1]));
  }

  Widget activityCard(Map<String, dynamic> activity) {
    return Container(
      key: Key(activity['activityName'] ?? ''),
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF6CBA0),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                activity['activityName'] ?? '',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              Text(
                '${activity['startTime'] ?? ''} - ${activity['endTime'] ?? ''}',
                style: const TextStyle(fontSize: 14, color: Colors.black54),
              ),
            ],
          ),
          Checkbox(
            value: activity['isCompleted'] ?? false,
            onChanged: (value) => _updateActivityStatus(activity, value),
            activeColor: Colors.green,
          ),
        ],
      ),
    );
  }

  Future<void> _updateActivityStatus(Map<String, dynamic> activity, bool? value) async {
    if (value == null) return;
    setState(() {
      activity['isCompleted'] = value;
    });

    final userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId != null) {
      try {
        await FirebaseFirestore.instance
            .collection('Patient')
            .doc(userId)
            .collection('Activates')
            .doc(activity['activityDocId'])
            .collection('ScheduledDates')
            .doc(activity['scheduledDateId'])
            .update({'isCompleted': value});
      } catch (e) {
        print('❌ Error updating isCompleted: $e');
      }
    }
  }

  Widget dateBox(String day, String date, bool isSelected) {
    return Container(
      key: Key(day),
      margin: const EdgeInsets.symmetric(horizontal: 5),
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
      decoration: BoxDecoration(
        color: isSelected ? Colors.brown : Colors.white,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Text(day, style: const TextStyle(fontSize: 14, color: Colors.grey)),
          const SizedBox(height: 5),
          Text(
            date,
            style: TextStyle(
              fontSize: 16,
              color: isSelected ? Colors.white : Colors.black,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
