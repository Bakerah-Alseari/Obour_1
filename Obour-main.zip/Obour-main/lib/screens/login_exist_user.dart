import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:obour_1/screens/signup_new_user.dart';
import 'components/selection_bar.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _rememberMe = false;
  bool _showPassword = false; // Track password visibility
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCEFE6),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildHeader(context),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const SizedBox(height: 20),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'تسجيل الدخول',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w900,
                            color: Color(0xFF373A40),
                            fontFamily: 'Inter',
                          ),
                        ),
                        const SizedBox(height: 5),
                        Container(
                          width: 145,
                          height: 3.5,
                          color: Color(0xFF373A40),
                        ),
                      ],
                    ),
                    const SizedBox(height: 36),
                    CustomTextField(
                      fieldKey: const Key('email_field'),
                      controller: _emailController,
                      label: 'البريد الإلكتروني',
                      hintText: 'ادخل بريدك الإلكتروني...',
                      icon: 'assets/images/email_Icone.png',
                      keyboardType: TextInputType.emailAddress,
                    ),
                    const SizedBox(height: 13),
                    CustomTextField(
                      fieldKey: const Key('password_field'),
                      controller: _passwordController,
                      label: 'كلمة المرور',
                      hintText: 'ادخل كلمة المرور الخاصة بك...',
                      icon: 'assets/images/lock_icone.png',
                      isPassword: true,
                      showPassword: _showPassword,
                      onTogglePassword: () {
                        setState(() {
                          _showPassword = !_showPassword;
                        });
                      },
                    ),
                    Row(
                      children: [
                        Checkbox(
                          value: _rememberMe,
                          activeColor: Color(0xFFBE5707),
                          onChanged: (bool? value) {
                            setState(() {
                              _rememberMe = value!;
                            });
                          },
                        ),
                        const Text(
                          "تذكرني",
                          style: TextStyle(
                            color: Color(0xFFBE5707),
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Inter',
                          ),
                        ),
                        Spacer(),
                      ],
                    ),
                    const SizedBox(height: 20),
                    GestureDetector(
                      key: const Key('login_button'),
                      onTap: _loginUser,
                      child: Container(
                        width: double.infinity,
                        padding: EdgeInsets.symmetric(vertical: 14),
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: Color(0xFF373A40),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          'تسجيل الدخول',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w500,
                            fontFamily: 'Inter',
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 15),
                    Center(
                      child: GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => SignupScreen()),
                          );
                        },
                        child: RichText(
                          textAlign: TextAlign.center,
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text: 'مستخدم جديد ؟ ',
                                style: TextStyle(
                                  color: Color(0xFFBE5707),
                                  fontSize: 16,
                                  fontFamily: 'Inter',
                                ),
                              ),
                              TextSpan(
                                text: 'قم بإنشاء حساب.',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 16,
                                  decoration: TextDecoration.underline,
                                  fontFamily: 'Inter',
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 30),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Stack(
      children: [
        Image.asset(
          'assets/images/scrUpper.png',
          fit: BoxFit.cover,
          width: double.infinity,
          height: 152,
        ),
        Positioned(
          top: 30,
          left: 0,
          right: 0,
          child: Image.asset(
            'assets/images/ObourLogoLight.png',
            width: 100,
            height: 100,
            fit: BoxFit.contain,
          ),
        ),
        Positioned(
          top: 70,
          right: 20,
          child: GestureDetector(
            onTap: () {
              Navigator.pop(context);
            },
            child: Image.asset(
              'assets/images/back_icone.png',
              width: 40,
              height: 40,
            ),
          ),
        ),
      ],
    );
  }

  void _loginUser() async {
    if (_formKey.currentState!.validate()) {
      try {
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: _emailController.text.trim(),
          password: _passwordController.text.trim(),
        );

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => MainScreen()),
        );
      } catch (error) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("خطأ: ${error.toString()}")),
        );
      }
    }
  }
}

class CustomTextField extends StatelessWidget {
  final Key? fieldKey;
  final String label;
  final String hintText;
  final String icon;
  final bool isPassword;
  final bool showPassword; // for toggle password visibility
  final VoidCallback? onTogglePassword;
  final TextInputType keyboardType;
  final TextEditingController controller;
  final String? errorText; // ✅ added to support dynamic error display
  final bool readOnly; // ✅ New parameter
  final VoidCallback? onTap; // ✅ Add this



  const CustomTextField({
    this.fieldKey,
    Key? key,
    required this.label,
    required this.hintText,
    required this.icon,
    required this.controller,
    this.isPassword = false,
    this.showPassword = false,
    this.onTogglePassword,
    this.keyboardType = TextInputType.text,
    this.errorText, // ✅ add to constructor
    this.readOnly = false, // ✅ default to false
    this.onTap, // ✅ Add this

  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    print('✅ Loing Screen is building...');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Align(
          alignment: Alignment.centerRight,
          child: Text(
            label,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
            textAlign: TextAlign.right,
          ),
        ),
        const SizedBox(height: 5),
        TextFormField(
          key: fieldKey,
          controller: controller,
          obscureText: isPassword && !showPassword,
          keyboardType: keyboardType,
          textAlign: TextAlign.right,
          decoration: InputDecoration(
            hintText: hintText,
            hintStyle: const TextStyle(fontSize: 14, color: Colors.grey),
            prefixIcon: Padding(
              padding: const EdgeInsets.all(10),
              child: Image.asset(icon, width: 20, height: 20),
            ),
            suffixIcon: isPassword
                ? IconButton(
              onPressed: onTogglePassword,
              icon: Image.asset(
                showPassword
                    ? 'assets/images/eye_off.png'
                    : 'assets/images/eye_on.png',
                width: 20,
                height: 20,
              ),
            )
                : null,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: Colors.grey),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: Colors.grey),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: Color(0xFF373A40)),
            ),
            errorText: errorText, // ✅ show external error (like short password)
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'هذا الحقل مطلوب';
            }
            if (keyboardType == TextInputType.emailAddress &&
                !RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(value)) {
              return 'يرجى إدخال بريد إلكتروني صحيح';
            }
            return null;
          },
        ),
      ],
    );
  }
}
