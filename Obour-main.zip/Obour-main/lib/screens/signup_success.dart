import 'package:flutter/material.dart';
import 'components/selection_bar.dart';
import 'activ_generate_weekly_plan.dart';

class SignUpSuccessScreen extends StatelessWidget {

  DateTime _findBeginningOfWeek(DateTime date) {
    return date.subtract(Duration(days: date.weekday % 7));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCEFE6),
      body: Column(
        children: [
          _buildHeader(context),
          Expanded(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(height: 30),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFF4CDB0),
                      padding: const EdgeInsets.symmetric(horizontal: 146, vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onPressed: () async {
                      DateTime today = DateTime.now();
                      DateTime thisSunday = _findBeginningOfWeek(today);

                      await generateWeeklySchedule(thisSunday); // 👈 no subtract!

                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('✅ تم توليد خطة الأسبوع الجديد!')),
                      );

                      Future.delayed(const Duration(milliseconds: 100), () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (context) => const MainScreen()),
                        );
                      });
                    },


                    child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 0),
                      child: Text(
                        'أنا مستعد',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 18,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Stack(
      children: [
        Image.asset(
          'assets/images/signupUpper.png',
          fit: BoxFit.cover,
          width: double.infinity,
          height: 590,
        ),
        Positioned(
          top: 270,
          left: 0,
          right: 0,
          child: Column(
            children: [
              Image.asset(
                'assets/images/ObourLogoLight.png',
                width: 150,
                height: 150,
                fit: BoxFit.contain,
              ),
              const Text(
                "تم إنشاء خطة نشاط أسبوعية لك...",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 5),
              const Text(
                "قم بالضغط على \"أنا مستعد\" لرؤيتها",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
        Positioned(
          top: 70,
          right: 20,
          child: GestureDetector(
            onTap: () {
              Navigator.pop(context); // Go back to previous screen
            },
            child: Image.asset(
              'assets/images/back_icone.png',
              width: 40,
              height: 40,
            ),
          ),
        ),
      ],
    );
  }
}
