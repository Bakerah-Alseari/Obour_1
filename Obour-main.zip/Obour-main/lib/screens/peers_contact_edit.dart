import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/date_symbol_data_local.dart';

class EditContactScreen extends StatefulWidget {
  final String initialName;
  final String initialPhone;
  final String contactId;

  const EditContactScreen({
    super.key,
    required this.initialName,
    required this.initialPhone,
    required this.contactId,
  });

  @override
  EditContactScreenState createState() => EditContactScreenState();
}

class EditContactScreenState extends State<EditContactScreen> {
  late TextEditingController nameController;
  late TextEditingController phoneController;

  @override
  void initState() {
    super.initState();
    initializeDateFormatting('ar', null);

    nameController = TextEditingController(text: widget.initialName);
    phoneController = TextEditingController(text: widget.initialPhone);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCEFE6),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              children: [
                Image.asset("assets/images/long.png", width: double.infinity, fit: BoxFit.cover),
                Positioned(
                  top: 70,
                  right: 20,
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Image.asset("assets/images/back_icone.png", width: 40, height: 40),
                  ),
                ),
                Positioned(
                  top: 50,
                  left: 16,
                  child: Image.asset("assets/images/EditSquare.png", width: 200, height: 200),
                ),
                const Positioned(
                  top: 130,
                  right: 90,
                  child: Text("تحرير", style: TextStyle(fontSize: 30, color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  _buildStyledInputField("اسم جهة الاتصال", nameController),
                  const SizedBox(height: 16),
                  _buildStyledInputField("رقم الهاتف", phoneController, isPhone: true),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF373A40),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                      onPressed: () async {
                        final user = FirebaseAuth.instance.currentUser;
                        if (user == null) return;

                        final docRef = FirebaseFirestore.instance
                            .collection('Patient')
                            .doc(user.uid)
                            .collection('contactPeer')
                            .doc(widget.contactId);

                        await docRef.update({
                          'PeerName': nameController.text.trim(),
                          'PeerPhoneNumber': phoneController.text.trim(),
                        });

                        Navigator.pop(context, true); // return true to trigger refresh
                      },
                      child: const Text("حفظ", style: TextStyle(fontSize: 18, color: Colors.white)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStyledInputField(String label, TextEditingController controller, {bool isPhone = false}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Container(
          margin: const EdgeInsets.symmetric(vertical: 8),
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.grey.shade300),
          ),
          child: TextField(
            controller: controller,
            keyboardType: isPhone ? TextInputType.phone : TextInputType.text,
            textAlign: TextAlign.right,
            style: const TextStyle(fontSize: 16),
            decoration: const InputDecoration(border: InputBorder.none),
          ),
        ),
      ],
    );
  }
}
