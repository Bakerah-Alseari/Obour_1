import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:just_audio/just_audio.dart';
import 'profile.dart';
import 'badges.dart';
import 'activ_home_screen.dart';
import 'media.dart';
import 'peers_contact.dart';

class PodcastScreen extends StatefulWidget {
  const PodcastScreen({super.key});

  @override
  State<PodcastScreen> createState() => _PodcastScreen();
}

class _PodcastScreen extends State<PodcastScreen> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  String? _currentlyPlaying;
  Duration _duration = Duration.zero;
  Duration _position = Duration.zero;

  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();

    // Listen to duration and position changes
    _audioPlayer.durationStream.listen((d) {
      if (d != null) {
        setState(() => _duration = d);
      }
    });

  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  Future<void> _playPodcast(String url, String title) async {
    try {
      await _audioPlayer.setUrl(url);
      _audioPlayer.play();
      setState(() {
        _currentlyPlaying = title;
      });
    } catch (e) {
      print("❌ Error playing podcast: $e");
    }
  }

  void _onItemTapped(int index) {
    late Widget screen;

    switch (index) {
      case 0:
        screen = const HomeScreen();
        break;
      case 1:
        screen = const Badges();
        break;
      case 2:
        screen = const Media();
        break;
      case 3:
        screen = const peersContact();
        break;
      case 4:
        screen = const Profile();
        break;
    }

    Navigator.push(context, MaterialPageRoute(builder: (context) => screen));
  }

  Widget navIcon(String imagePath, int index) {
    return GestureDetector(
      onTap: () => _onItemTapped(index),
      child: Image.asset(
        imagePath,
        width: 30,
        height: 30,
        color: _selectedIndex == index ? Colors.brown : Colors.black45,
      ),
    );
  }

  String _formatDuration(Duration d) {
    return d.inMinutes.toString().padLeft(2, '0') +
        ':' +
        (d.inSeconds % 60).toString().padLeft(2, '0');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCEFE6),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              _buildHeader(context),
              const SizedBox(height: 20),
              StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance.collection('Podcasts').snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  if (snapshot.hasError) {
                    return const Center(child: Text('⚠️ خطاأ في تحميل البودكاست '));
                  }

                  final podcasts = snapshot.data!.docs;

                  if (podcasts.isEmpty) {
                    return const Center(child: Text('لا توجد حلقات بودكاست حالياً'));
                  }

                  return Column(
                    children: podcasts.map((doc) {
                      final data = doc.data() as Map<String, dynamic>;
                      final title = data['podcastTitle'] ?? '';
                      final audioUrl = data['audioUrl'] ?? '';

                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        color: Colors.white,
                        elevation: 3,
                        child: ListTile(
                          title: Text(title),
                          subtitle: _currentlyPlaying == title
                              ? Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              StreamBuilder<Duration>(
                                stream: _audioPlayer.positionStream,
                                builder: (context, snapshot) {
                                  final position = snapshot.data ?? Duration.zero;

                                  return Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Slider(
                                        min: 0,
                                        max: _duration.inSeconds.toDouble(),
                                        value: position.inSeconds.clamp(0, _duration.inSeconds).toDouble(),
                                        onChanged: (value) {
                                          _audioPlayer.seek(Duration(seconds: value.toInt()));
                                        },
                                      ),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(_formatDuration(position)),
                                          Text(_formatDuration(_duration)),
                                        ],
                                      ),
                                    ],
                                  );
                                },
                              ),
                              Row(
                                children: [
                                  IconButton(
                                    icon: Icon(_audioPlayer.playing ? Icons.pause : Icons.play_arrow),
                                    onPressed: () {
                                      if (_audioPlayer.playing) {
                                        _audioPlayer.pause();
                                      } else {
                                        _audioPlayer.play();
                                      }
                                    },
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.stop),
                                    onPressed: () {
                                      _audioPlayer.stop();
                                      setState(() {
                                        _currentlyPlaying = null;
                                        _position = Duration.zero;
                                        _duration = Duration.zero;
                                      });
                                    },
                                  ),
                                ],
                              )
                            ],
                          )
                              : null,
                          trailing: IconButton(
                            icon: const Icon(Icons.play_arrow),
                            onPressed: () => _playPodcast(audioUrl, title),
                          ),
                        ),
                      );
                    }).toList(),
                  );
                },
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(30),
            boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 5, spreadRadius: 6)],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              navIcon('assets/images/calender.png', 0),
              navIcon('assets/images/Badge.png', 1),
              navIcon('assets/images/Media.png', 2),
              navIcon('assets/images/Contact.png', 3),
              navIcon('assets/images/Profile.png', 4),
            ],
          ),
        ),
      ),
    );
  }
}

Widget _buildHeader(BuildContext context) {
  return SizedBox(
    height: 250,
    child: Stack(
      children: [
        Positioned(
          child: Image.asset(
            'assets/images/Bg.png',
            fit: BoxFit.fill,
            width: double.infinity,
          ),
        ),
        Positioned(
          top: 30,
          right: 20,
          child: GestureDetector(
            onTap: () {
              Navigator.pop(context);
            },
            child: Image.asset(
              "assets/images/backOrange.png",
              width: 40,
              height: 40,
            ),
          ),
        ),
        Positioned(
          left: 20,
          right: 100,
          top: 70,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    Text(
                      "بودكاست",
                      style: TextStyle(
                        fontSize: 35,
                        color: Color(0xFF632B00),
                        fontWeight: FontWeight.bold,
                        fontFamily: "Inter",
                      ),
                    ),
                    SizedBox(height: 5),
                    Text(
                      "وسّع مدارِكك",
                      style: TextStyle(
                        fontSize: 20,
                        color: Color(0xFF632B00),
                        fontFamily: "Inter",
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                width: 190,
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Image.asset(
                    'assets/images/podcastBigger.png',
                    width: 150,
                    height: 150,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

