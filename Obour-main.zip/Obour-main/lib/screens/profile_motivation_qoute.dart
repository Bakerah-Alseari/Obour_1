import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'components/selection_bar.dart';
import 'profile.dart';

class Qoutenotfiy extends StatefulWidget {
  const Qoutenotfiy({super.key});

  @override
  State<Qoutenotfiy> createState() => _Qoutenotfiy();
}

class _Qoutenotfiy extends State<Qoutenotfiy> {
  Map<String, bool> phrases = {
    "اقتباسات": false,
    "تأكيدات إيجابية": false,
    "نصائح": false,
    "تشجيع": false,
  };

  List<String> previouslySaved = [];

  @override
  void initState() {
    super.initState();
    _loadQuoteTypesFromFirestore();
  }

  Future<void> _loadQuoteTypesFromFirestore() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final quotesRef = FirebaseFirestore.instance
        .collection('Patient')
        .doc(user.uid)
        .collection('Quotes');

    final snapshot = await quotesRef.get();
    final savedTypes = snapshot.docs.map((doc) => doc['QuoteType'] as String?).whereType<String>().toList();

    setState(() {
      for (String type in phrases.keys) {
        if (savedTypes.contains(type)) {
          phrases[type] = true;
          previouslySaved.add(type);
        }
      }
    });
  }

  Future<void> _saveChanges() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final quotesRef = FirebaseFirestore.instance
        .collection('Patient')
        .doc(user.uid)
        .collection('Quotes');

    for (String type in phrases.keys) {
      final isChecked = phrases[type]!;
      final wasSaved = previouslySaved.contains(type);

      if (isChecked && !wasSaved) {
        // Add new type
        await quotesRef.add({
          'QuoteType': type,
          'QuoteDate': null,
          'QuoteText': null,
        });
      } else if (!isChecked && wasSaved) {
        // Delete unchecked
        final snapshot = await quotesRef.where('QuoteType', isEqualTo: type).get();
        for (var doc in snapshot.docs) {
          await doc.reference.delete();
        }
      }
    }

    // ✅ Navigate to Profile screen after saving
    Navigator.pushReplacement(
      context,
        MaterialPageRoute(builder: (context) => const MainScreen(initialIndex: 4))
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCEFE6),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildHeader(context),
            const SizedBox(height: 20),
            _buildContent(),
            const SizedBox(height: 45),
            Padding(
              padding: const EdgeInsets.only(top: 35),
              child: GestureDetector(
                onTap: _saveChanges,
                child: Container(
                  width: 386,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: const Color(0xFF373A40),
                  ),
                  child: const Padding(
                    padding: EdgeInsets.symmetric(vertical: 15),
                    child: Text(
                      'حفظ التغييرات',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w500,
                        fontFamily: 'Inter',
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Stack(
      children: [
        Image.asset(
          'assets/images/scrUpper.png',
          fit: BoxFit.cover,
          width: double.infinity,
          height: 152,
        ),
        Positioned(
          top: 30,
          left: 0,
          right: 0,
          child: Image.asset(
            'assets/images/ObourLogoLight.png',
            width: 100,
            height: 100,
            fit: BoxFit.contain,
          ),
        ),
        Positioned(
          top: 70,
          right: 20,
          child: GestureDetector(
            onTap: () {
              Navigator.pop(context, 'goToProfile');
            },
            child: Image.asset(
              'assets/images/back_icone.png',
              width: 40,
              height: 40,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildContent() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 25),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const SizedBox(height: 50),
          Center(
            child: Column(
              children: [
                const Text(
                  'الجمل المحفزة',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF373A40),
                    fontFamily: 'Inter',
                  ),
                ),
                const SizedBox(height: 10),
                Container(
                  width: 183,
                  height: 3.5,
                  color: const Color(0xFF373A40),
                ),
                const SizedBox(height: 10),
                const Text(
                  'قم باختيار الجمل المحفزة بالنسبة لك',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 16,
                    color: Color(0xFFC65600),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          _buildDivider(),
          ...phrases.keys.map((String key) {
            return Column(
              children: [
                CheckboxListTile(
                  value: phrases[key],
                  onChanged: (bool? newValue) {
                    setState(() {
                      phrases[key] = newValue ?? false;
                    });
                  },
                  title: Text(
                    key,
                    textAlign: TextAlign.right,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w500,
                      color: Colors.black,
                    ),
                  ),
                  controlAffinity: ListTileControlAffinity.leading,
                  activeColor: const Color(0xFF373A40),
                ),
                _buildDivider(),
              ],
            );
          }).toList(),
        ],
      ),
    );
  }

  Widget _buildDivider() {
    return const Divider(
      color: Colors.grey,
      thickness: 1,
      height: 20,
    );
  }
}