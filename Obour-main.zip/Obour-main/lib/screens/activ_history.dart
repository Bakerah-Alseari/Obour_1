import 'dart:io' show Platform;
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:android_intent_plus/android_intent.dart';
import 'package:android_intent_plus/flag.dart';
import 'components/activ_alarm_permission_utils.dart';
import 'activ_notification_reminder.dart';


class ActivitiesHistory extends StatefulWidget {
  const ActivitiesHistory({super.key});

  @override
  State<ActivitiesHistory> createState() => _ActivitiesHistoryState();
}

class _ActivitiesHistoryState extends State<ActivitiesHistory> {
  DateTime selectedDate = DateTime.now();
  List<String> completedActivities = [];
  bool isLoading = false;
  bool _notificationsEnabled = false;

  @override
  void initState() {
    super.initState();
    _loadNotificationPreference();
    _fetchCompletedActivities();
  }

  Future<void> _fetchCompletedActivities() async {
    setState(() {
      isLoading = true;
      completedActivities.clear();
    });

    try {
      final uid = FirebaseAuth.instance.currentUser!.uid;
      final activatesSnapshot = await FirebaseFirestore.instance
          .collection('Patient')
          .doc(uid)
          .collection('Activates')
          .get();

      for (var activityDoc in activatesSnapshot.docs) {
        final activityName = activityDoc['ActivityName'];
        final scheduledDatesRef =
        activityDoc.reference.collection('ScheduledDates');
        final dateOnly =
        DateTime(selectedDate.year, selectedDate.month, selectedDate.day);
        final scheduledSnapshot = await scheduledDatesRef
            .where('isCompleted', isEqualTo: true)
            .get();

        for (var sched in scheduledSnapshot.docs) {
          final DateTime dt = (sched['scheduledDate'] as Timestamp).toDate();
          final scheduledDate = DateTime(dt.year, dt.month, dt.day);

          if (scheduledDate == dateOnly) {
            completedActivities.add(activityName);
          }
        }
      }
    } catch (e) {
      print('❌ Error fetching completed activities: $e');
    }

    setState(() {
      isLoading = false;
    });
  }

  Future<void> _saveNotificationPreference() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notifications_enabled', _notificationsEnabled);
  }

  Future<void> _loadNotificationPreference() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getBool('notifications_enabled') ?? false;
    setState(() {
      _notificationsEnabled = saved;
    });
  }

  Future<void> openAlarmPermissionSettings() async {
    if (Platform.isAndroid) {
      final intent = AndroidIntent(
        action: 'android.settings.REQUEST_SCHEDULE_EXACT_ALARM',
        flags: <int>[Flag.FLAG_ACTIVITY_NEW_TASK],
      );
      await intent.launch();
    }
  }

  Widget _buildDivider() => Divider(color: Colors.grey, thickness: 1, height: 20);

  String _getMonthName(int month) {
    const months = [
      'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
    ];
    return months[month - 1];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCEFE6),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildHeader(context),
            _buildContent(),
            const SizedBox(height: 45),
            Padding(
              padding: const EdgeInsets.only(top: 35),
              child: GestureDetector(
                onTap: () async {
                  await _saveNotificationPreference();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                        '✅ تم حفظ التغييرات بنجاح',
                        textAlign: TextAlign.right,
                      ),
                      backgroundColor: Color(0xFF373A40),
                      duration: Duration(seconds: 2),
                    ),
                  );
                },
                child: Container(
                  width: 386,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: Color(0xFF373A40),
                  ),
                  child: const Padding(
                    padding: EdgeInsets.symmetric(vertical: 15),
                    child: Text(
                      'حفظ التغييرات',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w500,
                        fontFamily: 'Inter',
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Stack(
      children: [
        Image.asset('assets/images/scrUpper.png', fit: BoxFit.cover, width: double.infinity, height: 152),
        Positioned(
          top: 30,
          left: 0,
          right: 0,
          child: Image.asset('assets/images/ObourLogoLight.png', width: 100, height: 100),
        ),
        Positioned(
          top: 70,
          right: 20,
          child: GestureDetector(
            onTap: () {
              Navigator.pop(context, 'goToProfile');
            },
            child: Image.asset('assets/images/back_icone.png', width: 40, height: 40),
          ),
        ),
      ],
    );
  }

  Widget _buildContent() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 25),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 50),
          Center(
            child: Column(
              children: [
                Text('الأنشطة', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: Color(0xFF373A40))),
                const SizedBox(height: 5),
                Container(width: 183, height: 3.5, color: Color(0xFF373A40)),
              ],
            ),
          ),
          const SizedBox(height: 36),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text('السماح بالإشعارات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 5),
                  Text('إشعارات التذكير بالأنشطة', style: TextStyle(fontSize: 14, color: Color(0xFFC65600))),
                ],
              ),
              Switch(
                value: _notificationsEnabled,
                onChanged: (bool value) async {
                  setState(() {
                    _notificationsEnabled = value;
                  });

                  if (value) {
                    final isGranted = await isExactAlarmPermissionGranted();

                    if (!isGranted) {
                      final confirm = await showDialog<bool>(
                        context: context,
                        builder: (context) => AlertDialog(
                          title: const Text('السماح بالتنبيه الدقيق'),
                          content: const Text('هل ترغب بالسماح لتطبيق عبور باستخدام إشعارات دقيقة لتذكيرك؟'),
                          actions: [
                            TextButton(child: const Text('لا'), onPressed: () => Navigator.pop(context, false)),
                            TextButton(child: const Text('نعم'), onPressed: () => Navigator.pop(context, true)),
                          ],
                        ),
                      );

                      if (confirm == true) {
                        await openAlarmPermissionSettings();
                      }
                    }

                    await scheduleDailyActivityReminder();

                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text(
                          '✅ تم تفعيل إشعار التذكير اليومي بالنشاط!',
                          textAlign: TextAlign.right,
                          style: TextStyle(color: Colors.white),
                        ),
                        backgroundColor: Color(0xFF373A40),
                        duration: Duration(seconds: 3),
                      ),
                    );
                  }
                },
                activeColor: Color(0xFF66BB6A),
              ),
            ],
          ),
          _buildDivider(),
          const SizedBox(height: 30),
          GestureDetector(
            onTap: () async {
              DateTime? pickedDate = await showDatePicker(
                context: context,
                initialDate: selectedDate,
                firstDate: DateTime(2000),
                lastDate: DateTime(2030),
              );
              if (pickedDate != null && pickedDate != selectedDate) {
                setState(() {
                  selectedDate = pickedDate;
                });
                await _fetchCompletedActivities();
              }
            },
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text('سجل الأنشطة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                const SizedBox(height: 10),
                Text('${selectedDate.day} ${_getMonthName(selectedDate.month)} ${selectedDate.year}',
                    style: TextStyle(fontSize: 16, color: Color(0xFFC65600))),
              ],
            ),
          ),
          _buildDivider(),
          const SizedBox(height: 30),
          Text('الأنشطة المكتملة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          isLoading
              ? Center(child: CircularProgressIndicator())
              : completedActivities.isEmpty

              ? Center(child: Text('لا توجد أنشطة مكتملة لهذا التاريخ', style: TextStyle(fontSize: 16)))
              : Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: completedActivities.map((activity) {
              return Padding(
                padding: const EdgeInsets.only(top: 5),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text('• $activity', textDirection: TextDirection.rtl, style: TextStyle(fontSize: 16, color: Color(0xFFC65600))),
                  ],
                ),
              );
            }).toList(),
          ),

          _buildDivider(),
        ],
      ),
    );
  }
}