import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:obour_1/main.dart'; // To access flutterLocalNotificationsPlugin



Future<void> scheduleDailyActivityReminder() async {
  try {
    // 🕗 Morning: 8:00 AM
    await _scheduleSingleNotification(
      id: 1,
      hour: 08,
      minute: 28,
    );

    // 🕒 Afternoon: 3:00 PM
    await _scheduleSingleNotification(
      id: 2,
      hour: 15,
      minute: 00,
    );

    // 🌙 Evening: 8:00 PM
    await _scheduleSingleNotification(
      id: 3,
      hour: 23,
      minute: 04,

    );

    print("✅ All daily reminders scheduled!");
  } catch (e) {
    print("❌ Error scheduling notifications: $e");
  }
}

Future<void> _scheduleSingleNotification({
  required int id,
  required int hour,
  required int minute,
}) async {
  final scheduledTime = _nextInstanceOfTime(hour, minute);
  print("🔔 Scheduling notification (ID: $id) at $scheduledTime");

  await flutterLocalNotificationsPlugin.zonedSchedule(
    id,
    'تذكير من عبور 🕊️',
    'خطوه اليوم تصنع فرق غدا! أكمل نشاطاتك واستمر نحو أهدافك',
    scheduledTime,
    const NotificationDetails(
      android: AndroidNotificationDetails(
        'activity_reminder_channel',
        'Activity Reminders',
        channelDescription: 'Multiple reminders to complete your activities',
        importance: Importance.max,
        priority: Priority.high,
      ),
    ),
    androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
    uiLocalNotificationDateInterpretation:
    UILocalNotificationDateInterpretation.absoluteTime,
    matchDateTimeComponents: DateTimeComponents.time,
  );
}




/// Helper function to get the next daily time (e.g., 8:00 PM)
tz.TZDateTime _nextInstanceOfTime(int hour, int minute) {
  final now = tz.TZDateTime.now(tz.local);
  final scheduled =
  tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);

  return scheduled.isBefore(now)
      ? scheduled.add(const Duration(days: 1))
      : scheduled;
}

