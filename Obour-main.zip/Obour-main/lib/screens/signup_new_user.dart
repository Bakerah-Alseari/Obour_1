import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:obour_1/screens/login_exist_user.dart';
import 'obour_onboarding.dart';
import 'signup_activity_selection.dart';
import 'components/signup_continue_button.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({Key? key}) : super(key: key);

  @override
  _SignupScreenState createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _birthdateController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String? _passwordError; // To store the password-specific error message

  @override
  void initState() {
    super.initState();
    // Listen to password field changes for real-time validation
    _passwordController.addListener(() {
      setState(() {
        if (_passwordController.text.isEmpty) {
          _passwordError = null; // Let the validator handle empty field
        } else if (_passwordController.text.length < 6) {
          _passwordError = 'كلمة المرور يجب أن تكون 6 أحرف أو أكثر';
        } else {
          _passwordError = null;
        }
      });
    });
  }

  @override
  void dispose() {
    _passwordController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _birthdateController.dispose();
    _nameController.dispose();
    super.dispose();
  }

  // Date picker function
  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(
                foregroundColor: const Color(0xFF373A40), // Button text color
              ),
            ),
            colorScheme: const ColorScheme.light(
              primary: Color(0xFF373A40), // Header background color
              onPrimary: Colors.white, // Header text color
              onSurface: Colors.black, // Body text color
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() {
        _birthdateController.text =
        "${picked.year}-${picked.month.toString().padLeft(2, '0')}-${picked.day.toString().padLeft(2, '0')}";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: MediaQuery.of(context).size.height,
        color: const Color(0xFFFCEFE6),
        child: SingleChildScrollView(
          child: Column(
            children: [
              _buildHeader(context),
              _buildForm(),
              const SizedBox(height: 45),
              GestureDetector(
                key: const Key('continue_button'), // for integration test
                onTap: _registerUser,
                child: ContinueButton(),
              ),
              const SizedBox(height: 8),
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: 'لديك حساب مسبق؟ ',
                      style: TextStyle(
                        color: Color(0xFFC65600),
                        fontSize: 16,
                      ),
                    ),
                    TextSpan(
                      text: 'قم بالتسجيل الدخول',
                      style: TextStyle(
                        color: Color(0xFF373A40),
                        fontSize: 16,
                        decoration: TextDecoration.underline,
                      ),
                      recognizer: TapGestureRecognizer()
                        ..onTap = () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => LoginScreen()),
                          );
                        },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Stack(
      children: [
        Image.asset(
          'assets/images/scrUpper.png',
          fit: BoxFit.cover,
          width: double.infinity,
          height: 152,
        ),
        Positioned(
          top: 30,
          left: 0,
          right: 0,
          child: Image.asset(
            'assets/images/ObourLogoLight.png',
            width: 100,
            height: 100,
            fit: BoxFit.contain,
          ),
        ),
        Positioned(
          top: 70,
          right: 20,
          child: GestureDetector(
            onTap: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => OnboardingScreen()),
              );
            },
            child: Image.asset(
              'assets/images/back_icone.png',
              width: 40,
              height: 40,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildForm() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 25),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 20),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'إنشاء حساب جديد',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF373A40),
                    fontFamily: 'Inter',
                  ),
                ),
                const SizedBox(height: 5),
                Container(
                  width: 183,
                  height: 3.5,
                  color: Color(0xFF373A40),
                ),
              ],
            ),
            const SizedBox(height: 36),
            CustomTextField(
              fieldKey: const Key('name_field'),
              controller: _nameController,
              label: 'الاسم',
              hintText: 'ادخل اسمك الكامل...',
              icon: 'assets/images/userB.png',
            ),
            const SizedBox(height: 13),
            CustomTextField(
              fieldKey: const Key('email_field'),
              controller: _emailController,
              label: 'البريد الإلكتروني',
              hintText: 'ادخل بريدك الإلكتروني...',
              icon: 'assets/images/email_Icone.png',
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 13),
            CustomTextField(
              fieldKey: const Key('password_field'),
              controller: _passwordController,
              label: 'كلمة المرور',
              hintText: 'ادخل كلمة المرور الخاصة بك...',
              icon: 'assets/images/lock_icone.png',
              isPassword: true,
              errorText: _passwordError, // Show real-time password length error
            ),
            const SizedBox(height: 13),
            CustomTextField(
              fieldKey: const Key('phone_field'),
              controller: _phoneController,
              label: 'رقم الجوال',
              hintText: 'ادخل رقم الجوال الخاص بك...',
              icon: 'assets/images/phone_icone.png',
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 13),
            CustomTextField(
              fieldKey: const Key('birthdate_field'),
              controller: _birthdateController,
              label: 'تاريخ الميلاد',
              hintText: 'اختر تاريخ ميلادك...',
              icon: 'assets/images/geryCalnder.png',
              readOnly: true,
              onTap: _selectDate,
            ),
          ],
        ),
      ),
    );
  }

  void _registerUser() async {
    if (_formKey.currentState!.validate() && _passwordError == null) {
      try {
        String name = _nameController.text.trim();
        String email = _emailController.text.trim();
        String password = _passwordController.text.trim();
        String phone = _phoneController.text.trim();
        String birthDate = _birthdateController.text.trim();

        UserCredential userCredential = await FirebaseAuth.instance
            .createUserWithEmailAndPassword(email: email, password: password);

        String uid = userCredential.user!.uid;

        await FirebaseFirestore.instance.collection('Patient').doc(uid).set({
          'name': name,
          'email': email,
          'phone': phone,
          'password': password,
          'birthDate': birthDate,
          'createdAt': FieldValue.serverTimestamp(),
        });

        print("🚀 Navigating to FavoriteActivitiesScreen");
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => FavoriteActivitiesScreen()),
        );
      } catch (error) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error: ${error.toString()}")),
        );
      }
    }
  }
}

class CustomTextField extends StatelessWidget {
  final Key? fieldKey; // ✅ Custom key for the internal TextFormField
  final String label;
  final String hintText;
  final String icon;
  final bool isPassword;
  final bool readOnly;
  final TextInputType keyboardType;
  final TextEditingController controller;
  final VoidCallback? onTap;
  final String? errorText; // To display the real-time error message

  const CustomTextField({
    this.fieldKey, // ✅
    required this.label,
    required this.hintText,
    required this.icon,
    required this.controller,
    this.isPassword = false,
    this.readOnly = false,
    this.keyboardType = TextInputType.text,
    this.onTap,
    this.errorText,
    Key? key,
  }): super(key: key); // Use optional widget key if needed

  Widget build(BuildContext context) {
    print('✅ SignupScreen is building...');
    return TextFormField(
      key: fieldKey,
      controller: controller,
      obscureText: isPassword,
      readOnly: readOnly,
      keyboardType: keyboardType,
      onTap: onTap,
      decoration: InputDecoration(
        labelText: label,
        hintText: hintText,
        prefixIcon: Image.asset(icon, width: 20, height: 20),
        border: OutlineInputBorder(),
        errorText: errorText,
        // Real-time error for password if needed
        errorStyle: TextStyle(color: Colors.red),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'هذا الحقل مطلوب';
        }

        if (isPassword && value.length < 6) {
          return 'كلمة المرور يجب أن تكون 6 أحرف أو أكثر';
        }

        // Email validation
        if (keyboardType == TextInputType.emailAddress) {
          final emailRegex = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
          if (!emailRegex.hasMatch(value)) {
            return 'الرجاء إدخال بريد إلكتروني صحيح مثل example@gmail.com';
          }
        }

        // Phone number validation
        if (keyboardType == TextInputType.phone) {
          final phoneRegex = RegExp(r'^(05\d{8}|966\d{9})$');
          if (!phoneRegex.hasMatch(value)) {
            return 'الرقم يجب أن يبدأ 05 أو 966 ويحتوي 10 أرقام على الأقل';
          }
        }

        return null;
      },
    );
  }
}
