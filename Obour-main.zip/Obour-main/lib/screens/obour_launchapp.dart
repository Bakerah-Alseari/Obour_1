import 'package:flutter/material.dart';
import 'obour_onboarding.dart'; // Import the next screen



class start_scr extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFA54700),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center, // Centers content vertically
        crossAxisAlignment: CrossAxisAlignment.center, // Centers content horizontally
        children: [
          // The image at the top
          Center(
            child: Image.asset(
              'assets/images/ObourWord.png', // Path to image asset
              width: 646,
              height: 371,
              fit: BoxFit.contain, // Ensure the image fits within the bounds
            ),
          ),

          // Add some space between the image and the button
          SizedBox(height: 130.0), // value to move the button down

          // The button
          Padding(
            padding: const EdgeInsets.only(bottom: 0.0), // value to move the button further down
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFFFAE7D9),
                foregroundColor: Color(0xFFA54700),
                padding: EdgeInsets.symmetric(horizontal: 76, vertical: 10),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => OnboardingScreen()),
                );
              },
              child: Text(
                'التالي',
                style: TextStyle(fontSize: 22),
              ),
            ),
          ),
        ],
      ),
    );
  }
}