import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'activ_history.dart';


class Badges extends StatefulWidget {
  const Badges({super.key});

  @override
  State<Badges> createState() => _Badges_screen();
}

class _Badges_screen extends State<Badges> {
  int doneActivitiesCount = 0;

  final List<Map<String, dynamic>> badges = [
    {"name": "الماس", "points": 500, "image": "assets/images/diamond.png", "imageCrop": "assets/images/diamond crop.png"},
    {"name": "ذهبية", "points": 400, "image": "assets/images/gold medal.png", "imageCrop": "assets/images/gold crop.png"},
    {"name": "فضية", "points": 275, "image": "assets/images/silver medal.png", "imageCrop": "assets/images/silver crop.png"},
    {"name": "برونزية", "points": 175, "image": "assets/images/bronze medal.png", "imageCrop": "assets/images/bronze crop.png"},
    {"name": "زرقاء", "points": 100, "image": "assets/images/blue medal.png", "imageCrop": "assets/images/blue crop.png"},
    {"name": "خضراء", "points": 50, "image": "assets/images/green medal.png", "imageCrop": "assets/images/green crop.png"},
  ];

  @override
  void initState() {
    super.initState();
    fetchCompletedActivities();
    //doneActivitiesCount = 100; // test value

  }

  Future<void> fetchCompletedActivities() async {
    try {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) return;

      final activatesSnapshot = await FirebaseFirestore.instance
          .collection('Patient')
          .doc(uid)
          .collection('Activates')
          .get();

      int completedCount = 0;

      for (var activityDoc in activatesSnapshot.docs) {
        final scheduledSnapshot = await FirebaseFirestore.instance
            .collection('Patient')
            .doc(uid)
            .collection('Activates')
            .doc(activityDoc.id)
            .collection('ScheduledDates')
            .where('isCompleted', isEqualTo: true)
            .get();

        completedCount += scheduledSnapshot.docs.length;
      }

      setState(() {
        doneActivitiesCount = completedCount;
      });
    } catch (e) {
      print('Error fetching completed activities: $e');
    }
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFDF1E9),
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            _buildActivityProgress(),
            _buildBadgesSection(),
          ],
        ),
      ),

    );
  }

  Widget _buildHeader() {
    return Container(
      child: Stack(
        children: [
          Positioned(
            child: Image.asset(
              'assets/images/Upper_Header.png',
              fit: BoxFit.cover,
            ),
          ),
          Positioned(
            top: 16,
            right: 16,
            child: GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ActivitiesHistory()),
                );
              },
              child: Image.asset(
                'assets/images/bell.png',
                width: 30,
                height: 30,
              ),
            ),
          ),
          Positioned(
            top: 35,
            right: 245,
            child: Image.asset(
              _getLatestUnlockedBadge(),
              alignment: Alignment.topLeft,
              fit: BoxFit.cover,
            ),
          ),
          Positioned(
            right: 20,
            top: 78,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _getLatestUnlockedBadgeName(),
                  style: TextStyle(
                    fontSize: 32,
                    color: Color(0xFF632B00),
                    fontWeight: FontWeight.bold,
                    fontFamily: "Inter",
                  ),
                ),
                Container(
                  width: 200,
                  child: Text(
                    "إنجازاتك تُهم، اجمع الشارات واحتفل بإنجازاتك!",
                    textAlign: TextAlign.right,
                    style: TextStyle(fontSize: 14, color: Color(0xFFC65600)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActivityProgress() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 90, vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "لقد قمت بإكمال",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF292C30),
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    "$doneActivitiesCount",
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFDC5F00),
                    ),
                  ),
                  Text(
                    "نشاط",
                    style: TextStyle(
                      fontSize: 15,
                      color: Color(0xFF292C30),
                    ),
                  ),
                ],
              ),
            ],
          ),
          SizedBox(height: 8),
          Divider(
            color: Color(0xFF999999),
            thickness: 0.8,
            indent: 5,
            endIndent: 5,
          ),
        ],
      ),
    );
  }

  Widget _buildBadgesSection() {
    return Expanded(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "شارات الإنجاز",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Color(0xFF292C30),
              ),
            ),
            SizedBox(height: 8),
            Expanded(
              child: GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 1,
                ),
                itemCount: badges.length,
                itemBuilder: (context, index) {
                  final badge = badges[index];
                  bool isUnlocked = doneActivitiesCount >= badge["points"];
                  return _buildBadgeItem(badge["image"], badge["name"], badge["points"], isUnlocked);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBadgeItem(String imagePath, String title, int points, bool isUnlocked) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: isUnlocked ? Color(0xFFB04C00) : Color(0xFFE6E6E6), width: 1.5),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Opacity(
            opacity: isUnlocked ? 1.0 : 0.3,
            child: Image.asset(
              imagePath,
              width: 60,
              height: 60,
            ),
          ),
          SizedBox(height: 8),
          Text(
            title,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: isUnlocked ? Color(0xFFB04C00) : Color(0xFF999999),
            ),
          ),
          Text(
            "$points نشاط",
            style: TextStyle(
              fontSize: 12,
              color: Color(0xFF999999),
            ),
          ),
        ],
      ),
    );
  }

  String _getLatestUnlockedBadge() {
    for (var badge in badges) {
      if (doneActivitiesCount >= badge["points"]) {
        return badge["imageCrop"] ?? "assets/images/contact_peer_header.png";
      }
    }
    return "assets/images/contact_peer_header.png";
  }

  String _getLatestUnlockedBadgeName() {
    for (var badge in badges) {
      if (doneActivitiesCount >= badge["points"]) {
        return badge["name"] ?? "تابع ، لا تتوقف";
      }
    }
    return "تابع ، لا تتوقف";
  }
}
