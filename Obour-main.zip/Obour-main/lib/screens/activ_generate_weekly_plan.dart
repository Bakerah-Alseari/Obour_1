import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';

DateTime _findBeginningOfWeek(DateTime date) {
  return date.subtract(Duration(days: date.weekday % 7));
}

Future<void> generateWeeklySchedule(DateTime weekStartDate) async {
  final userId = FirebaseAuth.instance.currentUser?.uid;
  if (userId == null) return;

  final firestore = FirebaseFirestore.instance;
  DateTime currentWeekStart = _findBeginningOfWeek(weekStartDate);

  final activatesSnapshot = await firestore
      .collection('Patient')
      .doc(userId)
      .collection('Activates')
      .orderBy('Priority')
      .get();

  List<Map<String, dynamic>> activities = activatesSnapshot.docs.map((doc) {
    return {
      'id': doc.id,
      'ActivityName': doc.data()['ActivityName'],
      'Priority': doc.data()['Priority'],
    };
  }).toList();

  final availabilitySnapshot = await firestore
      .collection('Patient')
      .doc(userId)
      .collection('Availability')
      .get();

  Map<String, Map<String, String>> availability = {};
  for (var doc in availabilitySnapshot.docs) {
    availability[doc.id] = {
      'start': doc.data()['start'],
      'end': doc.data()['end'],
    };
  }

  Map<String, List<Map<String, String>>> freeSlots = {};
  for (var day in availability.keys) {
    final start = availability[day]!['start']!;
    final end = availability[day]!['end']!;
    freeSlots[day] = _generateTimeSlots(start, end, 30);
  }

  List<DateTime> weekDates = List.generate(7, (index) => currentWeekStart.add(Duration(days: index)));


  for (var activity in activities) {
    final activityId = activity['id'];
    final activityRef = firestore.collection('Patient').doc(userId).collection('Activates').doc(activityId);

    final scheduledDatesSnapshot = await activityRef.collection('ScheduledDates').get();

    for (var doc in scheduledDatesSnapshot.docs) {
      final scheduledDate = (doc.data()['scheduledDate'] as Timestamp).toDate();
      if (weekDates.any((date) =>
      scheduledDate.year == date.year &&
          scheduledDate.month == date.month &&
          scheduledDate.day == date.day)) {
        await doc.reference.delete();
      }
    }
  }

  Map<String, List<Map<String, dynamic>>> dayUsedSlots = {};

  for (var activity in activities) {
    final activityId = activity['id'];
    final activityRef = firestore.collection('Patient').doc(userId).collection('Activates').doc(activityId);

    for (var date in weekDates) {
      String arabicDay = _getArabicDayName(date.weekday);

      if (!availability.containsKey(arabicDay) || (freeSlots[arabicDay]?.isEmpty ?? true)) continue;

      if (!dayUsedSlots.containsKey(arabicDay)) {
        dayUsedSlots[arabicDay] = [];
      }

      for (var slot in freeSlots[arabicDay]!) {
        bool slotOccupied = dayUsedSlots[arabicDay]!.any((used) => used['start'] == slot['start'] && used['end'] == slot['end']);

        if (!slotOccupied) {
          var scheduledDocRef = await activityRef.collection('ScheduledDates').add({
            'scheduledDate': Timestamp.fromDate(
              DateTime(date.year, date.month, date.day, int.parse(slot['start']!.split(":")[0]), int.parse(slot['start']!.split(":")[1])),
            ),
            'startTime': slot['start'],
            'endTime': slot['end'],
            'isCompleted': false,
          });

          dayUsedSlots[arabicDay]!.add({
            'activityId': activityId,
            'scheduledDateId': scheduledDocRef.id,
            'start': slot['start'],
            'end': slot['end'],
            'priority': activity['Priority'],
          });

          break;
        } else {
          var conflictActivity = dayUsedSlots[arabicDay]!.firstWhere((used) => used['start'] == slot['start'] && used['end'] == slot['end']);

          if (conflictActivity['priority'] > activity['Priority']) {
            await pushActivityLater(
                arabicDay,
                conflictActivity,
                freeSlots,
                dayUsedSlots,
                date,
                firestore,
                userId
            );

            await firestore
                .collection('Patient')
                .doc(userId)
                .collection('Activates')
                .doc(activityId)
                .collection('ScheduledDates')
                .doc(conflictActivity['scheduledDateId'])
                .update({
              'scheduledDate': Timestamp.fromDate(
                DateTime(date.year, date.month, date.day, int.parse(slot['start']!.split(":")[0]), int.parse(slot['start']!.split(":")[1])),
              ),
              'startTime': slot['start'],
              'endTime': slot['end'],
            });

            dayUsedSlots[arabicDay]!.remove(conflictActivity);
            dayUsedSlots[arabicDay]!.add({
              'activityId': activityId,
              'scheduledDateId': conflictActivity['scheduledDateId'],
              'start': slot['start'],
              'end': slot['end'],
              'priority': activity['Priority'],
            });

            break;
          }
        }
      }
    }
  }
}

Future<void> pushActivityLater(
    String day,
    Map<String, dynamic> conflictActivity,
    Map<String, List<Map<String, String>>> freeSlots,
    Map<String, List<Map<String, dynamic>>> dayUsedSlots,
    DateTime date,
    FirebaseFirestore firestore,
    String userId
    ) async {
  List<Map<String, String>> slots = freeSlots[day]!;

  for (var slot in slots) {
    bool slotOccupied = dayUsedSlots[day]!.any((used) => used['start'] == slot['start'] && used['end'] == slot['end']);

    if (!slotOccupied) {
      await firestore
          .collection('Patient')
          .doc(userId)
          .collection('Activates')
          .doc(conflictActivity['activityId'])
          .collection('ScheduledDates')
          .doc(conflictActivity['scheduledDateId'])
          .update({
        'startTime': slot['start'],
        'endTime': slot['end'],
        'scheduledDate': Timestamp.fromDate(
          DateTime(date.year, date.month, date.day, int.parse(slot['start']!.split(":")[0]), int.parse(slot['start']!.split(":")[1])),
        ),
      });

      dayUsedSlots[day]!.add({
        'activityId': conflictActivity['activityId'],
        'scheduledDateId': conflictActivity['scheduledDateId'],
        'start': slot['start'],
        'end': slot['end'],
        'priority': conflictActivity['priority'],
      });

      break;
    }
  }
}

List<Map<String, String>> _generateTimeSlots(String start, String end, int slotMinutes) {
  List<Map<String, String>> slots = [];
  try {
    List<String> startParts = start.split(":");
    List<String> endParts = end.split(":");

    int startHour = int.parse(startParts[0]);
    int startMinute = int.parse(startParts[1]);
    int endHour = int.parse(endParts[0]);
    int endMinute = int.parse(endParts[1]);

    DateTime startTime = DateTime(0, 1, 1, startHour, startMinute);
    DateTime endTime = DateTime(0, 1, 1, endHour, endMinute);

    if (endTime.isBefore(startTime)) endTime = endTime.add(const Duration(days: 1));

    while (startTime.isBefore(endTime)) {
      DateTime slotEnd = startTime.add(Duration(minutes: slotMinutes));
      if (slotEnd.isAfter(endTime)) break;

      slots.add({
        'start': DateFormat.Hm().format(startTime),
        'end': DateFormat.Hm().format(slotEnd),
      });

      startTime = slotEnd;
    }
  } catch (e) {
    print('❌ Error generating time slots: $e');
  }
  return slots;
}

String _getArabicDayName(int weekday) {
  switch (weekday) {
    case DateTime.sunday:
      return 'الأحد';
    case DateTime.monday:
      return 'الإثنين';
    case DateTime.tuesday:
      return 'الثلاثاء';
    case DateTime.wednesday:
      return 'الأربعاء';
    case DateTime.thursday:
      return 'الخميس';
    case DateTime.friday:
      return 'الجمعة';
    case DateTime.saturday:
      return 'السبت';
    default:
      return '';
  }
}
