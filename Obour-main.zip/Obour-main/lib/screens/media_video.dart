import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

class VideoScreen extends StatefulWidget {
  const VideoScreen({super.key});

  @override
  State<VideoScreen> createState() => _VideoScreen();
}

class _VideoScreen extends State<VideoScreen>{
  int _selectedIndex = 0; // Track selected tab



  //  Navigation Icon Widget (Handles Selection & Image Display)

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCEFE6),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              _buildHeader(context),
              const SizedBox(height: 20),

              // 🔽 StreamBuilder to fetch all videos
              StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance.collection('Videos').snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  if (snapshot.hasError) {
                    print("❌ Firestore error: ${snapshot.error}");
                    return const Center(child: Text('⚠️ خطأ في تحميل الفيديوهات'));
                  }

                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return const Center(child: Text('لا توجد فيديوهات'));
                  }

                  final videos = snapshot.data!.docs;

                  print("✅ Videos fetched: ${videos.length}");

                  return Column(
                    children: videos.map((video) {
                      final videoData = video.data() as Map<String, dynamic>;
                      final videoTitle = videoData['videoTitle'];
                      final videoUrl = videoData['videoUrl'];
                      final videoId = YoutubePlayer.convertUrlToId(videoUrl);

                      if (videoId == null) {
                        print("❌ Invalid video URL: $videoUrl");
                        return const SizedBox(); // Skip if URL is not valid
                      }

                      final controller = YoutubePlayerController(
                        initialVideoId: videoId,
                        flags: const YoutubePlayerFlags(autoPlay: false),
                      );

                      return Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          children: [
                            YoutubePlayer(controller: controller),
                            const SizedBox(height: 10),
                            Text(videoTitle ?? '', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                          ],
                        ),
                      );
                    }).toList(),
                  );
                },
              ),
            ],
          ),
        ),
      ),

      // ✅ Custom Bottom Navigation Bar
      bottomNavigationBar: SafeArea(
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(
                color: Colors.black12,
                blurRadius: 5,
                spreadRadius: 6,
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,

          ),
        ),
      ),
    );
  }
}
Widget _buildHeader(BuildContext context) {
  return SizedBox(
    height: 250, // Adjust height as needed
    child: Stack(
      children: [
        Positioned(
          child: Image.asset(
            'assets/images/Bg.png',
            fit: BoxFit.fill,
            width: double.infinity,
          ),
        ),

        // ✅ Custom Back Button (Top Right)
        Positioned(
          top: 30,
          right: 20,
          child: GestureDetector(
            onTap: () {
              Navigator.pop(context);
            },
            child: Image.asset(
              "assets/images/backOrange.png",
              width: 40,
              height: 40,
            ),
          ),
        ),



        // ✅ Properly Aligned Row for Text & Image
        Positioned(
          left: 20,
          right: 100,
          top: 70, // ✅ Adjusts row position properly
          child: Align(
            alignment: Alignment.centerRight,
            child: Align(
              alignment: Alignment.centerRight, // ✅ Pushes entire Row to the right
              child: Row(
                textDirection: TextDirection.rtl,
                mainAxisSize: MainAxisSize.min, // ✅ Prevents Row from expanding fully
                children: [
                  // ✅ Text Section (Right side in RTL)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      Text(
                        "فيديوهات",
                        style: TextStyle(
                          fontSize: 35,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF632B00),
                          fontFamily: "Inter",
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        "وسّع مدارِكك",
                        textAlign: TextAlign.right, // ✅ Ensures RTL alignment
                        style: TextStyle(
                          fontSize: 20,
                          color: Color(0xFF632B00),
                          fontFamily: "Inter",
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(width: 12),

                  // ✅ YouTube Icon (Left side in RTL)
                  SizedBox(
                    width: 100,
                    child: Center(
                      child: Image.asset(
                        'assets/images/Y.png',
                        width: 100,
                        height: 100,
                      ),
                    ),
                  ),
                ],
              ),
            ),

          ),

        ),
      ],
    ),
  );
}
