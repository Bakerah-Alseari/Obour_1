// send a message to an AI model (GPT-4o) through an HTTP API request
import 'dart:convert';
import 'package:http/http.dart' as http; // for sendingg web API requests

class ChatGPTService {
  static const String apiUrl = "https://models.inference.ai.azure.com/chat/completions"; // url for sending the request
  static const String apiKey = "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"; // authorization token to access the AI model

  // returns asynchronous it waits for the AI to answer
  static Future<String> generateQuote(String prompt, List<String> quoteTypes) async {
    try {
      final client = http.Client(); // for sendingg the request
      final Uri uri = Uri.parse(apiUrl); // to be used in client

      // Build the type string for better prompting
      final typeString = quoteTypes.join("، "); // Arabic comma

      final response = await client.post(
        uri, // Authorization header
        headers: {
          "Content-Type": "application/json", // tell server request body is json format
          "Authorization": "Bearer $apiKey",
        },
        body: jsonEncode({ // msg converted from dart to json
          "messages": [
            {
              "role": "system",
              "content":
              "أنت صديق داعم ومحفز يتحدث بأسلوب شخصي ودافئ باللغة العربية الفصحى. "
                  "لا تبدأ الرد بعبارات مثل (بالطبع، هذا اقتباس، إليك...). فقط تحدث مباشرة وكأنك تتحدث إلى صديق يحتاج الدعم."
                  " اجعل البداية عبارة تشجيعية قصيرة مرتبطة بحالته،"
                  " ثم ضع اقتباس ديني ملهم يناسب حالته النفسية ونوع الاقتباس المطلوب (مثل: نصيحة، تأكيدات، تشجيع...)."
            },
            {
              "role": "user", //  users specific emotional mood and type of qoute
              "content":
              "شخص يشعر بـ $prompt ويحب نوع الاقتباسات التالية: $typeString. كلمه كأنك تخاطبه بشكل مباشر وأضف اقتباساً دينياً مناسباً لحالته باللغة العربية الفصحى."
            }
          ],
          "model": "gpt-4o",
          "temperature": 1, // Creativity level
          "max_tokens": 4096, // maximum length of the response
          "top_p": 1 //  considers all possible next word
        }),
      );

      if (response.statusCode == 200) {
        final responseData = jsonDecode(utf8.decode(response.bodyBytes)); // Ensure UTF-8 Decoding
        return responseData["choices"][0]["message"]["content"];
      } else {
        throw Exception("Error: ${utf8.decode(response.bodyBytes)}"); // Decode Errors Properly
      }
    } catch (e) {
      return "Error: $e";
    }
  }
}
