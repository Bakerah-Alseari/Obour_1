import 'package:flutter/material.dart';
import 'activ_history.dart';
import 'media_video.dart';
import 'media_text.dart';
import 'media_podcast.dart';


class Media extends StatefulWidget {
  const Media({super.key});

  @override
  State<Media> createState() => _MediaState();
}

class _MediaState extends State<Media> {


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: const Color(0xFFFCEFE6),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              _buildHeader(),

              // ✅ Media Section
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const Text(
                      "الوسائط",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 20),

                    _buildMediaBox(
                      context,
                      title: "فيديوهات",
                      imagePath: 'assets/images/youtube.png',
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const VideoScreen()),
                     ),
                    ),
                    const SizedBox(height: 15),

                    _buildMediaBox(
                      context,
                      title: "معلومات نصية",
                      imagePath: 'assets/images/quote.png',
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const QuotesScreen()),
                      ),
                    ),
                    const SizedBox(height: 15),

                    _buildMediaBox(
                      context,
                      title: "بودكاست",
                      imagePath: 'assets/images/podcast.png',
                     onTap: () => Navigator.push(
                       context,
                       MaterialPageRoute(builder: (context) => const PodcastScreen()),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),


    );
  }





  Widget _buildMediaBox(BuildContext context, {required String title, required String imagePath, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: MediaQuery.of(context).size.width * 0.8, // Bigger width
        height: 150, // Bigger height
        padding: const EdgeInsets.all(16.0),
        decoration: BoxDecoration(
          color: const Color(0xFFF4CDB0),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 6,
              spreadRadius: 4,
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(imagePath, width: 60, height: 60), // Bigger images
            const SizedBox(height: 10),
            Text(
              title,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold), // Bigger text
            ),
          ],
        ),
      ),
    );
  }
}

  Widget _buildHeader() {
    return Container(
      child: Stack(
        children: [
          // ✅ Background Image
          Positioned(
            child: Image.asset(
              'assets/images/Bg.png',

              fit: BoxFit.fill,
              width: double.infinity,
            ),
          ),

          Positioned(
            top: 16,
            right: 16,
            child: Builder(
              builder: (context) => GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ActivitiesHistory()),
                  );
                },
                child: Image.asset(
                  'assets/images/bell.png',
                  width: 30,
                  height: 30,
                ),
              ),
            ),
          ),


          // ✅ Foreground Contact Image (Top Left)
          Positioned(
            top: 60,
            child: Image.asset(
              'assets/images/blogging.png',
              width: 450,
              height: 252.82,
              alignment: Alignment.topLeft,
            ),
          ),

          // ✅ Text Section (Right Side)
          Positioned(
            right: 20,
            top: 78,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                const Text(
                  "وسّع مدارِكك",  // ✅ Your original text here
                  style: TextStyle(
                    fontSize: 32,
                    color: Colors.brown,
                    fontWeight: FontWeight.bold,
                    fontFamily: "Inter",
                  ),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: 200,
                  child: const Text(
                    "تعلم من خلال محتوى متنوع يضم معلومات وفيديوهات وبودكاست لتعزيز الوعي بالصحة والتحديات الشخصية.ً",  // ✅ Your original subtitle text
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.brown,
                      fontFamily: "assets/fonts/Roboto-Regular.ttf",
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }




