import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'signup_activity_selection.dart';

class AddExtraActivityScreen extends StatefulWidget {
  const AddExtraActivityScreen({super.key});

  @override
  _AddExtraActivityScreenState createState() => _AddExtraActivityScreenState();
}

class _AddExtraActivityScreenState extends State<AddExtraActivityScreen> {
  final TextEditingController _activityController = TextEditingController();
  final List<String> _activities = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCEFE6),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildHeader(context),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 30),
                  const Center(
                    child: Text(
                      "إضافة أنشطة أخرى",
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _activityController,
                          decoration: InputDecoration(
                            hintText: "أدخل اسم النشاط....",
                            filled: true,
                            fillColor: Colors.white,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide.none,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      IconButton(
                        onPressed: () {
                          final newActivity = _activityController.text.trim();
                          if (newActivity.isNotEmpty) {
                            setState(() {
                              _activities.add(newActivity);
                              _activityController.clear();
                            });
                          }
                        },
                        icon: Image.asset('assets/images/add_button.png'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  _activities.isEmpty
                      ? const Center(child: Text("لم يتم إضافة أي أنشطة بعد"))
                      : ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _activities.length,
                    itemBuilder: (context, index) {
                      return Card(
                        margin: const EdgeInsets.symmetric(vertical: 5),
                        child: ListTile(
                          title: Text(
                            _activities[index],
                            textAlign: TextAlign.right,
                          ),
                          trailing: const Icon(
                            Icons.check_circle,
                            color: Colors.green,
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 20),
                  Padding(
                    padding: const EdgeInsets.only(top: 35),
                    child: GestureDetector(
                      onTap: () async {
                        if (_activities.isEmpty) return;

                        final user = FirebaseAuth.instance.currentUser;
                        if (user != null) {
                          final userId = user.uid;
                          final activatesRef = FirebaseFirestore.instance
                              .collection('Patient')
                              .doc(userId)
                              .collection('Activates');

                          for (String activity in _activities) {
                            await activatesRef.add({
                              "ActivityName": activity,
                              "ActivityDate": null,
                              "ActivityStatus": false,
                            });
                          }
                        }

                        // رجع القائمة للشاشة السابقة
                        Navigator.pop(context, _activities);
                      },
                      child: Container(
                        width: 386,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          color: const Color(0xFF373A40),
                        ),
                        child: const Padding(
                          padding: EdgeInsets.symmetric(vertical: 15),
                          child: Text(
                            'قم بالإضافة',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Stack(
      children: [
        Image.asset('assets/images/scrUpper.png', fit: BoxFit.cover, width: double.infinity, height: 152),
        Positioned(
          top: 30,
          left: 0,
          right: 0,
          child: Image.asset('assets/images/ObourLogoLight.png', width: 100, height: 100),
        ),
        Positioned(
          top: 70,
          right: 20,
          child: GestureDetector(
            onTap: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const FavoriteActivitiesScreen()),
              );
            },
            child: Image.asset('assets/images/back_icone.png', width: 40, height: 40),
          ),
        ),
      ],
    );
  }
}
