import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'activ_history.dart';
import 'peers_contact_add.dart';
import 'peers_contact_edit.dart';
import 'package:flutter/services.dart';


class peersContact extends StatefulWidget {
  const peersContact({super.key});

  @override
  State<peersContact> createState() => _PeersContactScreen();
}

class _PeersContactScreen extends State<peersContact> {
  List<Map<String, dynamic>> contacts = [];
  List<String> contactDocIds = [];
  int? selectedIndex;

  TextEditingController _searchController = TextEditingController();
  String searchQuery = "";

  @override
  void initState() {
    super.initState();
    fetchContactsFromFirestore();
  }

  Future<void> fetchContactsFromFirestore() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final contactRef = FirebaseFirestore.instance
        .collection('Patient')
        .doc(user.uid)
        .collection('contactPeer');

    final querySnapshot = await contactRef.get();
    final fetchedContacts = querySnapshot.docs.map((doc) {
      final data = doc.data();
      return {
        "name": data["PeerName"] ?? "",
        "phone": data["PeerPhoneNumber"] ?? "",
      };
    }).toList();

    final ids = querySnapshot.docs.map((doc) => doc.id).toList();

    setState(() {
      contacts = fetchedContacts;
      contactDocIds = ids;
    });
  }

  Future<void> deleteContactFromFirestore(int index) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final docId = contactDocIds[index];

    await FirebaseFirestore.instance
        .collection('Patient')
        .doc(user.uid)
        .collection('contactPeer')
        .doc(docId)
        .delete();

    fetchContactsFromFirestore();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCEFE6),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(0.0, 40.0, 0.0, 60.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            buildHeader(),
            buildContactsSection(),
          ],
        ),
      ),
      bottomSheet: selectedIndex != null ? buildBottomSheet() : null,

    );
  }


  Widget buildHeader() {
    return Stack(
      children: [
        Image.asset('assets/images/Upper_Header.png', fit: BoxFit.cover),
        // 🔔
        Positioned(
          top: 16,
          right: 16,
          child: Builder(
            builder: (context) => GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ActivitiesHistory()),
                );
              },
              child: Image.asset(
                'assets/images/bell.png',
                width: 30,
                height: 30,
              ),
            ),
          ),
        ),
        Positioned(
          top: 20,
          right: 200,
          child: Image.asset(
            'assets/images/contact_peer_header.png',
            width: 231,
            height: 176,
            alignment: Alignment.topLeft,
            fit: BoxFit.cover,
          ),
        ),
        Positioned(
          right: 20,
          top: 78,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("يدَكَ المُسانِدة",
                  style: TextStyle(fontSize: 32, color: Color(0xFF632B00), fontWeight: FontWeight.bold, fontFamily: "Inter")),
              Container(
                width: 200,
                child: Text("هنا تجد من يمد لك يد العون، لا تتردد أبداً في طلب المساعدة",
                    textAlign: TextAlign.right, style: TextStyle(fontSize: 14, color: Color(0xFFC65600))),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget buildContactsSection() {
    return Expanded(
      child: Container(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("جهات الاتصال",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, fontFamily: "Inter", color: Color(0xFF373A40))),
                TextButton(
                  onPressed: () async {
                    final newContacts = await Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const AddPeersContact()),
                    );
                    if (newContacts != null) {
                      fetchContactsFromFirestore();
                    }
                  },
                  child: Text("إضافة جهة اتصال +", style: TextStyle(fontSize: 15, color: Color(0xFF373A40))),
                ),
              ],
            ),
            SizedBox(height: 10),
            buildSearchField(),
            SizedBox(height: 5),
            Expanded(child: buildContactsList()),
          ],
        ),
      ),
    );
  }

  Widget buildSearchField() {
    return TextField(
      controller: _searchController,
      textAlign: TextAlign.right,
      onChanged: (value) {
        setState(() {
          searchQuery = value;
        });
      },
      decoration: InputDecoration(
        suffixIcon: Padding(
          padding: EdgeInsets.all(10),
          child: Image.asset('assets/images/ico-search.png', width: 20, height: 20),
        ),
        hintText: "البحث",
        fillColor: Colors.white,
        filled: true,
        contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 12),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Color(0xFFE6E6E6), width: 1.5),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Color(0xFFE6E6E6), width: 2.0),
        ),
      ),
    );
  }

  Widget buildContactsList() {
    final filteredContacts = contacts.where((contact) {
      final name = contact["name"] ?? "";
      return name.toLowerCase().contains(searchQuery.toLowerCase());
    }).toList();

    return ListView.builder(
      itemCount: filteredContacts.length,
      itemBuilder: (context, index) {
        final contact = filteredContacts[index];
        bool isSelected = index == selectedIndex;

        return GestureDetector(
          onTap: () {
            setState(() {
              selectedIndex = selectedIndex == index ? null : index;
            });
          },
          child: Card(
            color: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(
                color: isSelected ? Color(0xFFDC5F00) : Color(0xFFE6E6E6),
                width: isSelected ? 2.5 : 1.5,
              ),
            ),
            child: ListTile(
              trailing: PopupMenuButton<String>(
                icon: Image.asset('assets/images/3_dots.png', width: 24, height: 24),
                onSelected: (value) async {
                  if (value == "edit") {
                    final updated = await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => EditContactScreen(
                          initialName: contact["name"],
                          initialPhone: contact["phone"],
                          contactId: contactDocIds[index], //  Pass the document ID
                        ),
                      ),
                    );

                    if (updated != null) {
                      fetchContactsFromFirestore(); //  Refresh after edit
                    }
                  }
                  else if (value == "delete") {
                    _showDeleteConfirmationDialog(context, index);
                  }
                },
                itemBuilder: (context) => [
                  PopupMenuItem(
                    value: "edit",
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text("تحرير", style: TextStyle(fontSize: 14, color: Color(0xFF373A40))),
                        SizedBox(width: 8),
                        Image.asset('assets/images/Edit_Square.png', width: 24, height: 24),
                      ],
                    ),
                  ),
                  PopupMenuItem(
                    value: "delete",
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text("حذف", style: TextStyle(fontSize: 14, color: Color(0xFF373A40))),
                        SizedBox(width: 8),
                        Image.asset('assets/images/Delete.png', width: 24, height: 24),
                      ],
                    ),
                  ),
                ],
              ),
              leading: Image.asset('assets/images/Line 17.png', width: 10, height: 40),
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    contact["name"],
                    textAlign: TextAlign.right,
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF373A40)),
                  ),
                  Text(
                    contact["phone"],
                    textAlign: TextAlign.right,
                    style: TextStyle(fontSize: 16, color: Color(0xFF373A40)),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget buildBottomSheet() {
    return GestureDetector(
      onTap: () async {
        if (selectedIndex != null) {
          final contact = contacts[selectedIndex!];
          final phone = contact["phone"] ?? "966501414975"; // fallback phone number
          final message = "أمر بوقت صعب وأشعر أنني بحاجة لمساعدتك. دعمك لي الآن يعني لي الكثير"; // the message

          // Use the method channel to send SMS
          SmsHelper.sendSms(phone, message);
        }
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 100, vertical: 8),
        decoration: BoxDecoration(
          color: Color(0xFFFAE7D9),
          borderRadius: BorderRadius.all(Radius.circular(20)),
          border: Border.all(color: Color(0xFFF4CDB0), width: 1.5),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "أرسل رسالتك",
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: Color(0xFFB04C00),
              ),
            ),
            Text(
              "هم هنا للاستماع ودعمك",
              style: TextStyle(
                fontSize: 13,
                color: Color(0xFF4D2100),
              ),
            ),
          ],
        ),
      ),
    );
  }



  void _showDeleteConfirmationDialog(BuildContext context, int index) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 24, vertical: 16),
            decoration: BoxDecoration(
              color: Color(0xFFFAE7D9),
              borderRadius: BorderRadius.all(Radius.circular(20)),
              border: Border.all(color: Color(0xFFF4CDB0), width: 1.5),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Align(
                  alignment: Alignment.topRight,
                  child: GestureDetector(
                    onTap: () => Navigator.of(context).pop(),
                    child: Image.asset('assets/images/close.png', width: 24, height: 24),
                  ),
                ),
                SizedBox(height: 8),
                Text("هل أنت متأكد بأنك تريد حذف جهة الاتصال",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16, color: Color(0xFF4D2100))),
                SizedBox(height: 8),
                Text(
                  contacts[index]["name"]!,
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFFB04C00)),
                ),
                SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () async {
                        await deleteContactFromFirestore(index);
                        Navigator.of(context).pop();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color(0xFF8B4513),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        padding: EdgeInsets.symmetric(horizontal: 24, vertical: 10),
                      ),
                      child: Text("نعم", style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.bold)),
                    ),
                    SizedBox(width: 12),
                    ElevatedButton(
                      onPressed: () => Navigator.of(context).pop(),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color(0xFF8B4513),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        padding: EdgeInsets.symmetric(horizontal: 24, vertical: 10),
                      ),
                      child: Text("لا", style: TextStyle(fontSize: 16, color: Colors.white)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class SmsHelper {
  static const platform = MethodChannel('com.example.sms');

  static Future<void> sendSms(String phone, String message) async {
    try {
      await platform.invokeMethod('sendSms', {
        'phone': phone,
        'message': message,
      });
    } on PlatformException catch (e) {
      print("Failed to send SMS: '${e.message}'.");
    }
  }
}

