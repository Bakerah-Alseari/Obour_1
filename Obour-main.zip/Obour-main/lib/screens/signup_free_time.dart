import 'package:flutter/material.dart';
import 'signup_motivation_qoute.dart';
import 'components/signup_continue_button.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'signup_success.dart';

class FreeTimeSelectionScreen extends StatefulWidget {
  @override
  _FreeTimeSelectionScreenState createState() => _FreeTimeSelectionScreenState();
}

class _FreeTimeSelectionScreenState extends State<FreeTimeSelectionScreen> {
  final Map<String, bool> _selectedDays = {
    "الأحد": false,
    "الإثنين": false,
    "الثلاثاء": false,
    "الأربعاء": false,
    "الخميس": false,
    "الجمعة": false,
  };

  final Map<String, TimeOfDay?> _startTime = {};
  final Map<String, TimeOfDay?> _endTime = {};

  @override
  void initState() {
    super.initState();
    fetchAvailabilityFromFirestore();
  }

  Future<void> _selectTime(BuildContext context, String day, bool isStart) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: isStart
          ? (_startTime[day] ?? TimeOfDay(hour: 9, minute: 0))
          : (_endTime[day] ?? TimeOfDay(hour: 17, minute: 0)),
      builder: (context, child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: false),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        if (isStart) {
          if (_endTime[day] != null && !_isStartBeforeEnd(picked, _endTime[day]!)) {
            _showInvalidTimeDialog();
          } else {
            _startTime[day] = picked;
          }
        } else {
          if (_startTime[day] != null && !_isStartBeforeEnd(_startTime[day]!, picked)) {
            _showInvalidTimeDialog();
          } else {
            _endTime[day] = picked;
          }
        }
      });
    }
  }

  bool _isStartBeforeEnd(TimeOfDay start, TimeOfDay end) {
    final startMinutes = start.hour * 60 + start.minute;
    final endMinutes = end.hour * 60 + end.minute;
    return startMinutes < endMinutes;
  }

  void _showInvalidTimeDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("❌ خطأ في الوقت"),
        content: const Text("لا يمكن أن يكون وقت البداية بعد أو يساوي وقت النهاية. الرجاء التعديل."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("موافق"),
          ),
        ],
      ),
    );
  }

  Future<void> fetchAvailabilityFromFirestore() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final userId = user.uid;
    final availabilityRef = FirebaseFirestore.instance
        .collection('Patient')
        .doc(userId)
        .collection('Availability');

    final snapshot = await availabilityRef.get();

    for (var doc in snapshot.docs) {
      final day = doc.id;
      final data = doc.data();

      if (_selectedDays.containsKey(day)) {
        setState(() {
          _selectedDays[day] = true;

          final startString = data['start'];
          final endString = data['end'];

          if (startString != null && startString is String) {
            final parsedStart = DateFormat.Hm().parse(startString);
            _startTime[day] = TimeOfDay(hour: parsedStart.hour, minute: parsedStart.minute);
          }

          if (endString != null && endString is String) {
            final parsedEnd = DateFormat.Hm().parse(endString);
            _endTime[day] = TimeOfDay(hour: parsedEnd.hour, minute: parsedEnd.minute);
          }
        });
      }
    }
  }

  Future<void> saveAvailabilityToFirestore() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final userId = user.uid;
    final availabilityRef = FirebaseFirestore.instance
        .collection('Patient')
        .doc(userId)
        .collection('Availability');

    for (var day in _selectedDays.keys) {
      if (_selectedDays[day]! && _startTime.containsKey(day) && _endTime.containsKey(day)) {
        final start = _startTime[day]!;
        final end = _endTime[day]!;

        final startFormatted = "${start.hour.toString().padLeft(2, '0')}:${start.minute.toString().padLeft(2, '0')}";
        final endFormatted = "${end.hour.toString().padLeft(2, '0')}:${end.minute.toString().padLeft(2, '0')}";

        await availabilityRef.doc(day).set({
          'start': startFormatted,
          'end': endFormatted,
        });
      }
    }
  }

  Widget _buildHeader(BuildContext context) {
    return Stack(
      children: [
        Image.asset(
          'assets/images/scrUpper.png',
          fit: BoxFit.cover,
          width: double.infinity,
          height: 152,
        ),
        Positioned(
          top: 30,
          left: 0,
          right: 0,
          child: Image.asset(
            'assets/images/ObourLogoLight.png',
            width: 100,
            height: 100,
            fit: BoxFit.contain,
          ),
        ),
        Positioned(
          top: 70,
          right: 20,
          child: GestureDetector(
            onTap: () {
              Navigator.pop(context);
            },
            child: Image.asset(
              'assets/images/back_icone.png',
              width: 40,
              height: 40,
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCEFE6),
      body: Column(
        children: [
          _buildHeader(context),
          const SizedBox(height: 10),
          const Text(
            "ما هي الأيام التي يكون لديك فيها وقت فراغ؟ ومتى يكون ذلك؟",
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 21,
              fontWeight: FontWeight.w900,
              color: Color(0xFF373A40),
              fontFamily: 'Inter',
            ),
          ),
          const SizedBox(height: 5),
          Container(
            width: 215,
            height: 2.5,
            color: Color(0xFF373A40),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Expanded(
                    child: ListView(
                      children: _selectedDays.keys.map((day) {
                        return Card(
                          margin: const EdgeInsets.symmetric(vertical: 5),
                          child: Column(
                            children: [
                              ListTile(
                                title: Text(day, textAlign: TextAlign.right),
                                trailing: Switch(
                                  value: _selectedDays[day]!,
                                  activeColor: const Color(0xFFC65600),
                                  onChanged: (bool value) {
                                    setState(() {
                                      _selectedDays[day] = value;
                                      if (!value) {
                                        _startTime.remove(day);
                                        _endTime.remove(day);
                                      }
                                    });
                                  },
                                ),
                              ),
                              if (_selectedDays[day]!)
                                Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      TextButton(
                                        onPressed: () => _selectTime(context, day, true),
                                        child: Text(
                                          _startTime[day] != null
                                              ? formatTimeOfDay(_startTime[day]!)
                                              : "اختيار وقت البداية",
                                          style: const TextStyle(color: Colors.brown),
                                        ),
                                      ),

                                      const Text("إلى"),
                                      TextButton(
                                        onPressed: () => _selectTime(context, day, false),
                                        child: Text(
                                          _endTime[day] != null
                                              ? formatTimeOfDay(_endTime[day]!)
                                              : "اختيار وقت النهاية",
                                          style: const TextStyle(color: Colors.brown),
                                        ),
                                      ),

                                    ],
                                  ),
                                ),
                            ],
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () async {
                      await saveAvailabilityToFirestore();

                      final user = FirebaseAuth.instance.currentUser;
                      if (user != null) {
                        final quotesCollectionRef = FirebaseFirestore.instance
                            .collection('Patient')
                            .doc(user.uid)
                            .collection('Quotes');
                        final quotesSnapshot = await quotesCollectionRef.limit(1).get();

                        if (quotesSnapshot.metadata.isFromCache || quotesSnapshot.size > 0 || quotesSnapshot.docs.isNotEmpty) {
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(builder: (context) => SignUpSuccessScreen()),
                          );
                        } else {
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(builder: (context) => MotivationSelectionScreen()),
                          );
                        }
                      } else {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (context) => MotivationSelectionScreen()),
                        );
                      }
                    },
                    child: const ContinueButton(),
                  ),
                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  String formatTimeOfDay(TimeOfDay time) {
    final now = DateTime.now();
    final dt = DateTime(now.year, now.month, now.day, time.hour, time.minute);
    return DateFormat('h:mm a').format(dt); // ✅ Always AM/PM format
  }

}
