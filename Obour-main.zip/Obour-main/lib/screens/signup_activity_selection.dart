import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'components/selection_bar.dart';
import 'signup_add_extra_activ.dart';
import 'signup_commit_activ.dart';
import 'signup_new_user.dart';
import 'components/signup_continue_button.dart';

class FavoriteActivitiesScreen extends StatefulWidget {
  const FavoriteActivitiesScreen({super.key});

  @override
  _FavoriteActivitiesScreenState createState() => _FavoriteActivitiesScreenState();
}

class _FavoriteActivitiesScreenState extends State<FavoriteActivitiesScreen> {
  final Map<String, List<String>> activityOptions = {
    "الأنشطة البدنية": ["الجري", "السباحة", "ركوب الدراجة"],
    "الأنشطة الفكرية": ["القراءة", "الكتابة", "تعلم لغة جديدة", "لعبة أحجية الصور المقطوعة"],
    "الأنشطة الاجتماعية": ["التطوع", "التجمعات", "المشاركة في الفعاليات"],
    "الأنشطة الفنية": ["الرسم", "العزف", "التصوير"],
    "الأنشطة الروحية": ["التأمل", "الصلاة", "اليوغا"],
  };

  final Map<String, Set<String>> selectedActivities = {};
  final Map<String, bool> isExpanded = {};

  @override
  void initState() {
    super.initState();
    for (var category in activityOptions.keys) {
      selectedActivities[category] = {}; // No activity selected initially
      isExpanded[category] = false; // Collapsed initially
    }
    selectedActivities["أنشطة مضافة"] = {}; // For extra activities
    isExpanded["أنشطة مضافة"] = false;

    fetchAddedActivitiesFromFirestore(); // 🛠️ load saved activities
  }

  int get selectedCount =>
      selectedActivities.values.fold(0, (sum, list) => sum + list.length);

  Future<void> fetchAddedActivitiesFromFirestore() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final snapshot = await FirebaseFirestore.instance
        .collection('Patient')
        .doc(user.uid)
        .collection('Activates')
        .get();

    for (var doc in snapshot.docs) {
      final activityName = doc['ActivityName'];
      if (activityName != null && activityName is String) {
        bool matched = false;

        // ✨ نحاول نطابق النشاط مع أي قسم موجود
        activityOptions.forEach((category, activities) {
          if (activities.contains(activityName)) {
            selectedActivities[category]?.add(activityName);
            matched = true;
          }
        });

        // إذا لم يكن موجودًا بأي قسم
        if (!matched) {
          selectedActivities["أنشطة مضافة"]?.add(activityName);
        }
      }
    }

    setState(() {}); // 🔥 تحديث الشاشة بعد استرجاع الداتا
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCEFE6),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildHeader(context),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  const SizedBox(height: 10),
                  const Text(
                    "اختر الأنشطة المفضلة لديك",
                    style: TextStyle(
                      fontSize: 21,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFF373A40),
                      fontFamily: 'Inter',
                    ),
                  ),
                  const SizedBox(height: 5),
                  Container(
                    width: 215,
                    height: 2.5,
                    color: Color(0xFF373A40),
                  ),
                  const SizedBox(height: 10),

                  Align(
                    alignment: Alignment.centerLeft,
                    child: ElevatedButton.icon(
                      onPressed: () async {
                        await Navigator.push<List<String>>(
                          context,
                          MaterialPageRoute(builder: (context) => const AddExtraActivityScreen()),
                        );
                        // 📥 After returning from AddExtraActivityScreen, fetch updated activities
                        fetchAddedActivitiesFromFirestore();
                      },
                      icon: Image.asset(
                        'assets/images/plus.png', // <-- your image path
                        width: 24, // adjust size
                        height: 24,
                        color: Colors.white, // optional: if you want to color the image
                      ),

                      label: const Text("إضافة أنشطة أخرى"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                      ),
                    ),
                  ),

                  const SizedBox(height: 10),

                  Column(
                    children: activityOptions.entries.map((entry) {
                      return _buildExpandableList(entry.key, entry.value);
                    }).toList()
                      ..add(_buildExpandableList("أنشطة مضافة", selectedActivities["أنشطة مضافة"]!.toList())),
                  ),

                  const SizedBox(height: 20),
                  Text(
                    "عدد الأنشطة المختارة: $selectedCount",
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),

                  GestureDetector(
                    onTap: selectedCount > 0
                        ? () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => CommitFavoriteActivitiesScreen(
                            selectedActivities: selectedActivities.values.expand((set) => set).toList(),
                          ),
                        ),
                      );
                    }
                        : null,
                    child: const ContinueButton(),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildExpandableList(String category, List<String> activities) {
    if (activities.isEmpty) return const SizedBox(); // Skip if no activities

    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      elevation: 2,
      child: Column(
        children: [
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 16),
            title: Align(
              alignment: Alignment.centerRight,
              child: Text(
                category,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.orange),
              ),
            ),
            leading: Image.asset('assets/images/arrow_icone.png', width: 24, height: 24),
            trailing: getActivityIcon(category),
            onTap: () {
              setState(() {
                isExpanded[category] = !(isExpanded[category] ?? false);
              });
            },
          ),
          if (isExpanded[category] ?? false)
            Column(
              children: activities.map((activity) {
                return CheckboxListTile(
                  title: Align(
                    alignment: Alignment.centerRight,
                    child: Text(activity),
                  ),
                  value: selectedActivities[category]!.contains(activity),
                  onChanged: (bool? selected) {
                    setState(() {
                      if (selected!) {
                        selectedActivities[category]!.add(activity);
                      } else {
                        selectedActivities[category]!.remove(activity);
                      }
                    });
                  },
                  controlAffinity: ListTileControlAffinity.leading,
                );
              }).toList(),
            ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Stack(
      children: [
        Image.asset(
          'assets/images/scrUpper.png',
          fit: BoxFit.cover,
          width: double.infinity,
          height: 152,
        ),
        Positioned(
          top: 30,
          left: 0,
          right: 0,
          child: Image.asset(
            'assets/images/ObourLogoLight.png',
            width: 100,
            height: 100,
            fit: BoxFit.contain,
          ),
        ),
        Positioned(
          top: 70,
          right: 20,
          child: GestureDetector(
            onTap: () {
              final user = FirebaseAuth.instance.currentUser;

              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => user != null ? MainScreen(initialIndex: 0) : SignupScreen(),
                ),
              );
            },
            child: Image.asset(
              'assets/images/back_icone.png',
              width: 40,
              height: 40,
            ),
          ),
        ),
      ],
    );
  }

  Widget getActivityIcon(String category) {
    switch (category) {
      case "الأنشطة البدنية":
        return Image.asset('assets/images/tabler_run.png', width: 24, height: 24);
      case "الأنشطة الفكرية":
        return Image.asset('assets/images/mindfulness-outline.png', width: 24, height: 24);
      case "الأنشطة الاجتماعية":
        return Image.asset('assets/images/clarity_group-solid.png', width: 24, height: 24);
      case "الأنشطة الفنية":
        return Image.asset('assets/images/la_brush.png', width: 24, height: 24);
      case "الأنشطة الروحية":
        return Image.asset('assets/images/icon-park-outline_heart.png', width: 24, height: 24);
      default:
        return Image.asset('assets/images/plus.png', width: 24, height: 24,  color: Colors.orange,);
    }
  }
}
