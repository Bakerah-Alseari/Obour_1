import 'package:flutter/services.dart';

const MethodChannel _channel = MethodChannel('com.obour/alarm_permission');

Future<bool> isExactAlarmPermissionGranted() async {
  try {
    final bool isGranted = await _channel.invokeMethod('isExactAlarmGranted');
    return isGranted;
  } catch (e) {
    return false; // fallback
  }
}
