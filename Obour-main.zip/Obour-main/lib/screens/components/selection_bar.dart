import 'package:flutter/material.dart';
import '../badges.dart';
import '../activ_home_screen.dart';
import '../media.dart';
import '../profile.dart';
import '../peers_contact.dart';

class MainScreen extends StatefulWidget {
  final int initialIndex;

  const MainScreen({Key? key, this.initialIndex = 0}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  late int _selectedIndex;

  @override
  void initState() {
    super.initState();
    _selectedIndex = widget.initialIndex; // Set the initial tab
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  Widget _getScreen(int index) {
    switch (index) {
      case 0:
        return const HomeScreen();
      case 1:
        return const Badges();
      case 2:
        return const Media();
      case 3:
        return const peersContact();
      case 4:
        return const Profile();
      default:
        return const HomeScreen();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCEFE6),
      body: _getScreen(_selectedIndex),
      bottomNavigationBar: buildBottomNavigationBar(),
    );
  }

  Widget buildBottomNavigationBar() {
    return SafeArea(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(30),
          boxShadow: const [
            BoxShadow(color: Colors.black12, blurRadius: 5, spreadRadius: 6),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            navIcon('assets/images/calender.png', 0),
            navIcon('assets/images/Badge.png', 1),
            navIcon('assets/images/Media.png', 2),
            navIcon('assets/images/Contact.png', 3),
            navIcon('assets/images/Profile.png', 4),
          ],
        ),
      ),
    );
  }

  Widget navIcon(String imagePath, int index) {
    return GestureDetector(
      onTap: () => _onItemTapped(index),
      child: Image.asset(
        imagePath,
        width: 30,
        height: 30,
        color: _selectedIndex == index ? const Color(0xFF632B00) : Colors.black45,
      ),
    );
  }
}