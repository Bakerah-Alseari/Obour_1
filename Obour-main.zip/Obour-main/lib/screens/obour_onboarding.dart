import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart'; // Import for TapGestureRecognizer
import 'signup_new_user.dart'; // Import the sign-up screen
import 'login_exist_user.dart';


class OnboardingScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFCE8D5),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // image and text widgets
            Padding(
              padding: const EdgeInsets.only(top: 270.0),
              child: Column(
                children: [
                  Image.asset(
                    'assets/images/ObourLogo.png',
                    width: 378,
                    height: 237,
                    fit: BoxFit.contain,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10.0),
                    child: Text(
                      'لنكن جسر العبور الذي يوصلك\n...بيداً بيد إلى التغير',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFC65600),
                        fontFamily: 'Roboto',
                      ),
                    ),
                  ),
                ],
              ),
            ),

            Spacer(),

            // Button section
            Padding(
              padding: const EdgeInsets.only(bottom: 100.0),
              child: Column(
                children: [
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xFFA44700),
                      foregroundColor: Colors.white,
                      padding: EdgeInsets.symmetric(horizontal: 50, vertical: 6),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => SignupScreen()),
                      );
                    },
                    child: Text(
                      'ابدأ الآن',
                      style: TextStyle(fontSize: 18),
                    ),
                  ),
                  SizedBox(height: 0),
                  RichText(
                    text: TextSpan(
                      children: [
                        // First part: "لديك حساب مسبق؟"
                        TextSpan(
                          text: 'لديك حساب مسبق؟ ',
                          style: TextStyle(
                            color: Color(0xFFC65600),
                            fontSize: 16,
                          ),
                        ),
                        // Second part: "قم بالتسجيل الدخول"
                        TextSpan(
                          text: 'قم بالتسجيل الدخول',
                          style: TextStyle(
                            color: Color(0xFF373A40),
                            fontSize: 16,
                            decoration: TextDecoration.underline, // Underline for link
                          ),
                          recognizer: TapGestureRecognizer()
                            ..onTap = () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => LoginScreen()),
                              );
                            },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
