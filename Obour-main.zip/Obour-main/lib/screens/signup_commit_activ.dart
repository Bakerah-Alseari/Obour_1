import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'signup_prioritize_activityscr.dart';
import 'signup_activity_selection.dart';

class CommitFavoriteActivitiesScreen extends StatefulWidget {
  final List<String> selectedActivities;

  const CommitFavoriteActivitiesScreen({super.key, required this.selectedActivities});

  @override
  _CommitFavoriteActivitiesScreenState createState() => _CommitFavoriteActivitiesScreenState();
}

class _CommitFavoriteActivitiesScreenState extends State<CommitFavoriteActivitiesScreen> {
  late Map<String, bool> _selectedActivities;

  @override
  void initState() {
    super.initState();
    _selectedActivities = {
      for (var activity in widget.selectedActivities) activity: true
    };
  }

  int get _selectedCount => _selectedActivities.values.where((isSelected) => isSelected).length;

  Future<void> saveActivitiesToFirestore() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      print("User not logged in.");
      return;
    }

    final String userId = user.uid;
    final DocumentReference patientDoc =
    FirebaseFirestore.instance.collection("Patient").doc(userId);

    // تأكد أن وثيقة المستخدم موجودة
    await patientDoc.set({"createdAt": FieldValue.serverTimestamp()}, SetOptions(merge: true));

    final CollectionReference activitiesRef = patientDoc.collection("Activates");

    //  جلب جميع الأنشطة الحالية من Firestore
    final existingActivitiesSnapshot = await activitiesRef.get();
    final existingActivities = existingActivitiesSnapshot.docs.map((doc) => doc['ActivityName'] as String).toList();

    //  قائمة الأنشطة الحالية المختارة
    final selectedActivities = _selectedActivities.entries
        .where((entry) => entry.value)
        .map((entry) => entry.key)
        .toList();

    //  حذف الأنشطة التي لم تعد موجودة في الاختيارات
    for (var activityName in existingActivities) {
      if (!selectedActivities.contains(activityName)) {
        // حذف النشاط من Firestore
        final activityDoc = existingActivitiesSnapshot.docs.firstWhere((doc) => doc['ActivityName'] == activityName);
        await activitiesRef.doc(activityDoc.id).delete();
        print("🗑️ تم حذف النشاط: $activityName");
      }
    }

    //  إضافة الأنشطة الجديدة إن لم تكن موجودة
    for (var entry in _selectedActivities.entries) {
      if (entry.value) {
        final querySnapshot = await activitiesRef
            .where('ActivityName', isEqualTo: entry.key)
            .limit(1)
            .get();

        if (querySnapshot.docs.isEmpty) {
          await activitiesRef.add({
            "ActivityName": entry.key,
            "ActivityDate": null,
            "ActivityStatus": false,
          });
          print("✅ تم إضافة النشاط الجديد: ${entry.key}");
        } else {
          print("ℹ️ النشاط موجود مسبقاً: ${entry.key}");
        }
      }
    }

    print("🎯 حفظ التغييرات في الأنشطة (إضافة/حذف) تم بنجاح!");
  }



  Widget _buildHeader(BuildContext context) {
    return Stack(
      children: [
        Image.asset(
          'assets/images/scrUpper.png',
          fit: BoxFit.cover,
          width: double.infinity,
          height: 152,
        ),
        Positioned(
          top: 30,
          left: 0,
          right: 0,
          child: Image.asset(
            'assets/images/ObourLogoLight.png',
            width: 100,
            height: 100,
            fit: BoxFit.contain,
          ),
        ),
        Positioned(
          top: 70,
          right: 20,
          child: GestureDetector(
            onTap: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const FavoriteActivitiesScreen()),
              );
            },
            child: Image.asset(
              'assets/images/back_icone.png',
              width: 40,
              height: 40,
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCEFE6),
      body: Column(
        children: [
          _buildHeader(context),
          Expanded(
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    const SizedBox(height: 30),
                    const Text(
                      "الأنشطة المفضلة المختارة",
                      style: TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF373A40),
                        fontFamily: 'Inter',
                      ),
                    ),
                    const SizedBox(height: 5),
                    Container(
                      width: 200,
                      height: 2.5,
                      color: const Color(0xFF373A40),
                    ),
                    const SizedBox(height: 10),
                    Container(
                      constraints: BoxConstraints(
                        maxHeight: MediaQuery.of(context).size.height * 0.5,
                      ),
                      child: ListView.builder(
                        shrinkWrap: true,
                        physics: const AlwaysScrollableScrollPhysics(),
                        itemCount: _selectedActivities.length,
                        itemBuilder: (context, index) {
                          String activity = _selectedActivities.keys.elementAt(index);
                          return Card(
                            margin: const EdgeInsets.symmetric(vertical: 5),
                            child: CheckboxListTile(
                              title: Text(activity, textAlign: TextAlign.right),
                              value: _selectedActivities[activity]!,
                              onChanged: (bool? value) {
                                setState(() {
                                  _selectedActivities[activity] = value!;
                                });
                              },
                              activeColor: Colors.green,
                              controlAffinity: ListTileControlAffinity.leading,
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          "عدد الأنشطة المختارة",
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(width: 10),
                        Text(
                          "$_selectedCount",
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.red),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Container(
                      width: 386,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: const Color(0xFF78A670),
                      ),
                      child: InkWell(
                        onTap: () async {
                          await saveActivitiesToFirestore();
                          if (mounted) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => PrioritizeActivitiesScreen(
                                  selectedActivities: _selectedActivities.entries
                                      .where((entry) => entry.value)
                                      .map((entry) => entry.key)
                                      .toList(),
                                ),
                              ),
                            );
                          }
                        },
                        child: const Padding(
                          padding: EdgeInsets.symmetric(vertical: 15),
                          child: Text(
                            'أوافق على الأنشطة',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
