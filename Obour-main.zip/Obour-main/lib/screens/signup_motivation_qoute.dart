import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:obour_1/screens/signup_success.dart';
import 'components/signup_continue_button.dart';

class MotivationSelectionScreen extends StatefulWidget {
  @override
  _MotivationSelectionScreenState createState() => _MotivationSelectionScreenState();
}

class _MotivationSelectionScreenState extends State<MotivationSelectionScreen> {
  @override
  void initState() {
    super.initState();
    fetchSelectedMotivations(); // 🛠️ استرجاع المحفزات المختارة من فايرستور
  }

  final Map<String, bool> _motivations = {
    "التقديرات": false,
    "تأكيدات إيجابية": false,
    "نصائح": false,
    "التشجيع": false,


  };

  ///  Save selected QuoteTypes to Firestore under Patient/{userId}/Quotes
  Future<void> saveSelectedMotivations() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      print("User not logged in");
      return;
    }

    final String userId = user.uid;
    final CollectionReference quoteRef = FirebaseFirestore.instance
        .collection("Patient")
        .doc(userId)
        .collection("Quotes");

    for (var entry in _motivations.entries) {
      if (entry.value) {
        await quoteRef.add({
          "QuoteType": entry.key,
          "QuoteText": null,    // to be filled later
          "QuoteDate": null,    // to be filled later
        });
      }
    }

    print("✅ QuoteTypes saved to Firestore.");
  }

  Future<void> fetchSelectedMotivations() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final String userId = user.uid;
    final CollectionReference quoteRef = FirebaseFirestore.instance
        .collection("Patient")
        .doc(userId)
        .collection("Quotes");

    final snapshot = await quoteRef.get();

    for (var doc in snapshot.docs) {
      final data = doc.data() as Map<String, dynamic>;
      final quoteType = data['QuoteType'];

      if (quoteType != null && _motivations.containsKey(quoteType)) {
        setState(() {
          _motivations[quoteType] = true; //  عمل صح على المحفوظ
        });
      }
    }
  }


  Widget _buildHeader(BuildContext context) {
    return Stack(
      children: [
        Image.asset(
          'assets/images/scrUpper.png',
          fit: BoxFit.cover,
          width: double.infinity,
          height: 152,
        ),
        Positioned(
          top: 30,
          left: 0,
          right: 0,
          child: Image.asset(
            'assets/images/ObourLogoLight.png',
            width: 100,
            height: 100,
            fit: BoxFit.contain,
          ),
        ),
        Positioned(
          top: 70,
          right: 20,
          child: GestureDetector(
            onTap: () {
              Navigator.pop(context);
            },
            child: Image.asset(
              'assets/images/back_icone.png',
              width: 40,
              height: 40,
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCEFE6),
      body: Column(
        children: [
          _buildHeader(context),
          const SizedBox(height: 20),
          const Text(
            "ما نوع الكلام الذي يمكن أن يحفزك على الاستمرار؟",
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Color(0xFF373A40),
            ),
          ),
          const SizedBox(height: 10),
          Container(
            width: 200,
            height: 2,
            color: Color(0xFF373A40),
          ),
          const SizedBox(height: 20),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              children: _motivations.keys.map((motivation) {
                return Card(
                  margin: const EdgeInsets.symmetric(vertical: 5),
                  child: CheckboxListTile(
                    title: Text(motivation, textAlign: TextAlign.right),
                    value: _motivations[motivation],
                    onChanged: (bool? value) {
                      setState(() {
                        _motivations[motivation] = value!;
                      });
                    },
                    activeColor: Colors.green,
                    controlAffinity: ListTileControlAffinity.leading,
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 20),
          GestureDetector(
            onTap: () async {
              await saveSelectedMotivations(); //  Save to Firestore
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SignUpSuccessScreen()),
              );
            },
            child: const ContinueButton(),
          ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}
