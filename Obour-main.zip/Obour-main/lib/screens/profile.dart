import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'activ_history.dart';
import 'profile_motivation_qoute.dart';
import 'profile_edit.dart';
import 'obour_onboarding.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _Profile();
}

class _Profile extends State<Profile> {
  String _userName = '';

  @override
  void initState() {
    super.initState();
    fetchUserName();
  }

  Future<void> fetchUserName() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final uid = user.uid;
      final doc = await FirebaseFirestore.instance.collection('Patient').doc(uid).get();
      if (doc.exists) {
        final data = doc.data();
        if (data != null && data['name'] != null) {
          setState(() {
            _userName = data['name'];
          });
        }
      }
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCEFE6),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              _buildHeader(),
              const SizedBox(height: 50),
              GridView.count(
                shrinkWrap: true,
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                padding: const EdgeInsets.all(20),
                children: [
                  _buildGridItem(context, "الأنشطة", "assets/images/calender.png", () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => ActivitiesHistory()));
                  }),
                  _buildGridItem(context, "الحساب", "assets/images/ProfileW.png", () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => Editprofile()));
                  }),
                  _buildGridItem(context, "الجمل المحفزة", "assets/images/EditQoute.png", () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => Qoutenotfiy()));
                  }),
                  _buildGridItem(context, "تسجيل خروج", "assets/images/Logout.png", () {
                    _showLogoutDialog(context);
                  }),
                ],
              ),
            ],
          ),
        ),
      ),

    );
  }

  Widget _buildHeader() {
    return Stack(
      children: [
        Positioned(
          child: Image.asset(
            'assets/images/Bg.png',
            fit: BoxFit.fill,
            width: double.infinity,
          ),
        ),
        Positioned(
          top: 16,
          right: 16,
          child: GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ActivitiesHistory()),
              );
            },
            child: Image.asset(
              'assets/images/bell.png',
              width: 30,
              height: 30,
            ),
          ),
        ),
        Positioned(
          top: 70,
          left: 0,
          right: 0,
          child: Column(
            children: [
              Image.asset(
                'assets/images/user.png',
                width: 120,
                height: 120,
              ),
              Text(
                _userName.isNotEmpty ? _userName : 'اسم المستخدم',
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),

      ],
    );
  }

  Widget _buildGridItem(BuildContext context, String title, String imagePath, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFFF4CDB0),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: const Color(0xFFDC5F00),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Image.asset(imagePath, width: 40, height: 40),
            ),
            const SizedBox(height: 10),
            Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("تسجيل الخروج"),
        content: const Text("هل تريد تسجيل الخروج؟"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("إلغاء"),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              FirebaseAuth.instance.signOut().then((_) {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => OnboardingScreen()),
                      (route) => false,
                );
              }).catchError((error) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("خطأ: ${error.toString()}")),
                );
              });
            },
            child: const Text("تأكيد"),
          ),
        ],
      ),
    );
  }
}
