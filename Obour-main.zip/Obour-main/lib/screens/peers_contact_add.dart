import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AddPeersContact extends StatefulWidget {
  const AddPeersContact({super.key});

  @override
  _AddPeersContactState createState() => _AddPeersContactState();
}

class _AddPeersContactState extends State<AddPeersContact> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final List<Map<String, String>> _contacts = [];

  Future<void> _saveContactsToFirestore() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final String userId = user.uid;
    final CollectionReference contactsRef = FirebaseFirestore.instance
        .collection('Patient')
        .doc(userId)
        .collection('contactPeer');

    for (var contact in _contacts) {
      await contactsRef.add({
        'PeerName': contact['name'],
        'PeerPhoneNumber': contact['phone'],
      });
    }
  }

  void _showDeleteConfirmationDialog(BuildContext context, int index) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 24, vertical: 16),
            decoration: BoxDecoration(
              color: Color(0xFFFAE7D9),
              borderRadius: BorderRadius.all(Radius.circular(20)),
              border: Border.all(color: Color(0xFFF4CDB0), width: 1.5),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Align(
                  alignment: Alignment.topRight,
                  child: GestureDetector(
                    onTap: () => Navigator.of(context).pop(),
                    child: Image.asset(
                      'assets/images/close.png',
                      width: 24,
                      height: 24,
                    ),
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  "هل أنت متأكد بأنك تريد حذف جهة الاتصال",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 16,
                    color: Color(0xFF4D2100),
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  _contacts[index]["name"]!,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFB04C00),
                  ),
                ),
                SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          _contacts.removeAt(index);
                        });
                        Navigator.of(context).pop();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color(0xFF8B4513),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        padding: EdgeInsets.symmetric(horizontal: 24, vertical: 10),
                      ),
                      child: Text(
                        "نعم",
                        style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ),
                    SizedBox(width: 12),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color(0xFF8B4513),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        padding: EdgeInsets.symmetric(horizontal: 24, vertical: 10),
                      ),
                      child: Text(
                        "لا",
                        style: TextStyle(fontSize: 16, color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCEFE6),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildHeader(context),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 30),
                  const Center(
                    child: Text(
                      "إضافة جهة اتصال",
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Column(
                    children: [
                      TextField(
                        controller: _nameController,
                        textDirection: TextDirection.rtl,
                        textAlign: TextAlign.right,
                        keyboardType: TextInputType.name,
                        decoration: InputDecoration(
                          hintText: "أدخل اسم جهة الاتصال",
                          // hintStyle: TextStyle(fontFamily: "Tajawal"),
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _phoneController,
                        textDirection: TextDirection.rtl,
                        textAlign: TextAlign.right,
                        keyboardType: TextInputType.phone,
                        decoration: InputDecoration(
                          hintText: "أدخل رقم جهة الاتصال",
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                      const SizedBox(height: 15),
                      Center(
                        child: IconButton(
                          onPressed: () {
                            String name = _nameController.text.trim();
                            String phone = _phoneController.text.trim();

                            // Validation
                            bool isValidPhone = (phone.startsWith('05') || phone.startsWith('966')) && phone.length >= 10;

                            if (name.isNotEmpty && phone.isNotEmpty) {
                              if (isValidPhone) {
                                setState(() {
                                  _contacts.add({
                                    "name": name,
                                    "phone": phone,
                                  });
                                });
                                _nameController.clear();
                                _phoneController.clear();
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text(
                                      "❗ رقم الهاتف يجب أن يبدأ بـ 05 أو 966 ويكون 10 أرقام أو أكثر",
                                      textDirection: TextDirection.rtl,
                                    ),
                                    backgroundColor: Colors.redAccent,
                                  ),
                                );
                              }
                            }
                          },
                          icon: Image.asset('assets/images/add_button.png'),
                          padding: const EdgeInsets.all(8.0),
                        ),
                      ),

                    ],
                  ),
                  const SizedBox(height: 20),
                  _contacts.isEmpty
                      ? const Center(child: Text("لم يتم إضافة أي جهة اتصال بعد"))
                      : ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _contacts.length,
                    itemBuilder: (context, index) {
                      return Card(
                        color: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                          side: BorderSide(
                            color: Color(0xFFE6E6E6),
                            width: 2.5,
                          ),
                        ),
                        margin: const EdgeInsets.symmetric(vertical: 5),
                        child: ListTile(
                          contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          leading: Image.asset(
                            'assets/images/Line 17.png',
                            width: 10,
                            height: 40,
                          ),
                          trailing: GestureDetector(
                            onTap: () => _showDeleteConfirmationDialog(context, index),
                            child: Image.asset(
                              'assets/images/Delete.png',
                              width: 24,
                              height: 24,
                            ),
                          ),
                          title: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _contacts[index]["name"]!,
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFF373A40),
                                ),
                              ),
                              Text(
                                _contacts[index]["phone"]!,
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Color(0xFF999999),
                                ),
                              ),
                            ],
                          ),
                        ),

                      );
                    },
                  ),
                  const SizedBox(height: 20),
                  Padding(
                    padding: const EdgeInsets.only(top: 35),
                    child: GestureDetector(
                      onTap: () async {
                        if (_contacts.isNotEmpty) {
                          await _saveContactsToFirestore();
                          Navigator.pop(context);
                        }
                      },
                      child: Container(
                        width: 386,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          color: const Color(0xFF373A40),
                        ),
                        child: const Padding(
                          padding: EdgeInsets.symmetric(vertical: 15),
                          child: Text(
                            'حفظ جهات الاتصال',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Stack(
      children: [
        Image.asset(
          'assets/images/scrUpper.png',
          fit: BoxFit.cover,
          width: double.infinity,
          height: 152,
        ),
        Positioned(
          top: 30,
          left: 0,
          right: 0,
          child: Image.asset(
            'assets/images/ObourLogoLight.png',
            width: 100,
            height: 100,
            fit: BoxFit.contain,
          ),
        ),
        Positioned(
          top: 70,
          right: 20,
          child: GestureDetector(
            onTap: () {
              Navigator.pop(context);
            },

            child: Image.asset(
              'assets/images/back_icone.png',
              width: 40,
              height: 40,
            ),
          ),
        ),
      ],
    );
  }
}