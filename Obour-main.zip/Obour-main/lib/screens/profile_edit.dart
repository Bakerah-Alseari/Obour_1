import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'components/selection_bar.dart';
import 'profile.dart';

class Editprofile extends StatefulWidget {
  const Editprofile({super.key});

  @override
  State<Editprofile> createState() => _EditprofileState();
}

class _EditprofileState extends State<Editprofile> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _currentPasswordController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _birthdateController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadProfileData();
  }

  Future<void> _loadProfileData() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final doc = await FirebaseFirestore.instance.collection('Patient').doc(user.uid).get();
      if (doc.exists) {
        final data = doc.data();
        setState(() {
          _nameController.text = data?['name'] ?? '';
          _emailController.text = user.email ?? '';
          _phoneController.text = data?['phone'] ?? '';
          _birthdateController.text = data?['birthDate'] ?? '';
        });
      }
    }
  }

  Future<void> _saveChanges() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    try {
      final newEmail = _emailController.text.trim();
      final newPassword = _passwordController.text.trim();
      final currentEmail = user.email ?? '';
      final currentPassword = _currentPasswordController.text.trim();

      // Reauthenticate if email or password is being updated
      if ((newEmail.isNotEmpty && newEmail != currentEmail) || newPassword.isNotEmpty) {
        if (currentPassword.isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('يرجى إدخال كلمة المرور الحالية')),
          );
          return;
        }
        final cred = EmailAuthProvider.credential(
          email: currentEmail,
          password: currentPassword,
        );
        await user.reauthenticateWithCredential(cred);
      }

      // Update email if changed
      if (newEmail.isNotEmpty && newEmail != currentEmail) {
        if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(newEmail)) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('يرجى إدخال بريد إلكتروني صحيح')),
          );
          return;
        }
        if (!user.emailVerified) {
          await user.sendEmailVerification();
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('يرجى التحقق من البريد الإلكتروني أولاً')),
          );
          return;
        }
        await user.updateEmail(newEmail);
      }

      // Update password if provided
      if (newPassword.isNotEmpty) {
        if (newPassword.length < 6) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('كلمة المرور يجب أن تكون 6 أحرف على الأقل')),
          );
          return;
        }
        await user.updatePassword(newPassword);
      }

      // Update Firestore data
      await FirebaseFirestore.instance.collection('Patient').doc(user.uid).set({
        'name': _nameController.text.trim(),
        'email': newEmail,
        'phone': _phoneController.text.trim(),
        'birthDate': _birthdateController.text.trim(),
        if (newPassword.isNotEmpty) 'password': newPassword, // Add this line
      }, SetOptions(merge: true));

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم حفظ التغييرات بنجاح')),
      );

      // Navigate back to Profile screen
      Navigator.pushReplacement(
        context,
          MaterialPageRoute(builder: (context) => const MainScreen(initialIndex: 4))
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('خطأ: ${e.toString()}')),
      );
    }
  }

  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(
                foregroundColor: const Color(0xFF373A40), // Button text color
              ),
            ),
            colorScheme: const ColorScheme.light(
              primary: Color(0xFF373A40), // Header background color
              onPrimary: Colors.white, // Header text color
              onSurface: Colors.black, // Body text color
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() {
        _birthdateController.text = "${picked.year}-${picked.month.toString().padLeft(2, '0')}-${picked.day.toString().padLeft(2, '0')}";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCEFE6),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildHeader(context),
            _buildForm(),
            const SizedBox(height: 45),
            Padding(
              padding: const EdgeInsets.only(top: 35),
              child: GestureDetector(
                onTap: _saveChanges,
                child: Container(
                  width: 386,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: const Color(0xFF373A40),
                  ),
                  child: const Padding(
                    padding: EdgeInsets.symmetric(vertical: 15),
                    child: Text(
                      'حفظ التغييرات',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w500,
                        fontFamily: 'Inter',
                      ),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildForm() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 25),
      child: Form(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 50),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'الحساب',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF373A40),
                    fontFamily: 'Inter',
                  ),
                ),
                const SizedBox(height: 5),
                Container(
                  width: 183,
                  height: 3.5,
                  color: const Color(0xFF373A40),
                ),
              ],
            ),
            const SizedBox(height: 36),
            CustomTextField(
              label: 'اسم المستخدم',
              hintText: 'اسم المستخدم...',
              icon: 'assets/images/icon-park-outline_edit-name.png',
              controller: _nameController,
            ),
            const SizedBox(height: 13),
            CustomTextField(
              label: 'البريد الإلكتروني',
              hintText: 'البريد الإلكتروني...',
              icon: 'assets/images/email_Icone.png',
              controller: _emailController,
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 13),
            CustomTextField(
              label: 'كلمة المرور الجديدة',
              hintText: 'كلمة المرور الجديدة...',
              icon: 'assets/images/lock_icone.png',
              isPassword: true,
              controller: _passwordController,
            ),
            const SizedBox(height: 13),
            CustomTextField(
              label: 'كلمة المرور الحالية',
              hintText: 'أدخل كلمة المرور الحالية...',
              icon: 'assets/images/lock_icone.png',
              isPassword: true,
              controller: _currentPasswordController,
            ),
            const SizedBox(height: 13),
            CustomDatePickerField(
              label: 'تاريخ الميلاد',
              hintText: 'اختر تاريخ الميلاد...',
              icon: 'assets/images/geryCalnder.png',
              controller: _birthdateController,
              onTap: _selectDate,
            ),
            const SizedBox(height: 13),
            CustomTextField(
              label: 'رقم الجوال',
              hintText: 'رقم الجوال...',
              icon: 'assets/images/phone_icone.png',
              keyboardType: TextInputType.phone,
              controller: _phoneController,
            ),
          ],
        ),
      ),
    );
  }
}

class CustomTextField extends StatelessWidget {
  final String label;
  final String hintText;
  final String icon;
  final bool isPassword;
  final TextInputType keyboardType;
  final TextEditingController controller;

  const CustomTextField({
    Key? key,
    required this.label,
    required this.hintText,
    required this.icon,
    required this.controller,
    this.isPassword = false,
    this.keyboardType = TextInputType.text,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Align(
          alignment: Alignment.centerRight,
          child: Text(
            label,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
            textAlign: TextAlign.right,
          ),
        ),
        const SizedBox(height: 5),
        TextFormField(
          controller: controller,
          obscureText: isPassword,
          keyboardType: keyboardType,
          textAlign: TextAlign.right,
          decoration: InputDecoration(
            hintText: hintText,
            hintStyle: const TextStyle(fontSize: 14, color: Colors.grey),
            prefixIcon: Padding(
              padding: const EdgeInsets.all(10),
              child: Image.asset(icon, width: 20, height: 20),
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: Colors.grey),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: Colors.grey),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: Color(0xFF373A40)),
            ),
          ),
        ),
      ],
    );
  }
}

class CustomDatePickerField extends StatelessWidget {
  final String label;
  final String hintText;
  final String icon;
  final TextEditingController controller;
  final VoidCallback onTap;

  const CustomDatePickerField({
    Key? key,
    required this.label,
    required this.hintText,
    required this.icon,
    required this.controller,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Align(
          alignment: Alignment.centerRight,
          child: Text(
            label,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
            textAlign: TextAlign.right,
          ),
        ),
        const SizedBox(height: 5),
        GestureDetector(
          onTap: onTap,
          child: AbsorbPointer(
            child: TextFormField(
              controller: controller,
              textAlign: TextAlign.right,
              decoration: InputDecoration(
                hintText: hintText,
                hintStyle: const TextStyle(fontSize: 14, color: Colors.grey),
                prefixIcon: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Image.asset(icon, width: 20, height: 20),
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: Colors.grey),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: Colors.grey),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: Color(0xFF373A40)),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

Widget _buildHeader(BuildContext context) {
  return Stack(
    children: [
      Image.asset(
        'assets/images/scrUpper.png',
        fit: BoxFit.cover,
        width: double.infinity,
        height: 152,
      ),
      Positioned(
        top: 30,
        left: 0,
        right: 0,
        child: Image.asset(
          'assets/images/ObourLogoLight.png',
          width: 100,
          height: 100,
          fit: BoxFit.contain,
        ),
      ),
      Positioned(
        top: 70,
        right: 20,
        child: GestureDetector(
          onTap: () {
            Navigator.pop(context, 'goToProfile');
          },

          child: Image.asset(
            'assets/images/back_icone.png',
            width: 40,
            height: 40,
          ),
        ),
      ),
    ],
  );
}