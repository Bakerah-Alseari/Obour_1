import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'signup_free_time.dart';
import 'signup_activity_selection.dart';
import 'components/signup_continue_button.dart';

class PrioritizeActivitiesScreen extends StatefulWidget {
  final List<String> selectedActivities;

  const PrioritizeActivitiesScreen({super.key, required this.selectedActivities});

  @override
  _PrioritizeActivitiesScreenState createState() => _PrioritizeActivitiesScreenState();
}

class _PrioritizeActivitiesScreenState extends State<PrioritizeActivitiesScreen> {
  late List<String> _prioritizedActivities;

  @override
  void initState() {
    super.initState();
    _prioritizedActivities = List.from(widget.selectedActivities);
  }

  Widget _buildHeader(BuildContext context) {
    return Stack(
      children: [
        Image.asset(
          'assets/images/scrUpper.png',
          fit: BoxFit.cover,
          width: double.infinity,
          height: 152,
        ),
        Positioned(
          top: 30,
          left: 0,
          right: 0,
          child: Image.asset(
            'assets/images/ObourLogoLight.png',
            width: 100,
            height: 100,
            fit: BoxFit.contain,
          ),
        ),
        Positioned(
          top: 70,
          right: 20,
          child: GestureDetector(
            onTap: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => FavoriteActivitiesScreen()),
              );
            },
            child: Image.asset(
              'assets/images/back_icone.png',
              width: 40,
              height: 40,
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCEFE6),
      body: Column(
        children: [
          _buildHeader(context),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  const SizedBox(height: 10),
                  const Text(
                    "ترتيب انشطتك المفضلة",
                    style: TextStyle(
                      fontSize: 21,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFF373A40),
                      fontFamily: 'Inter',
                    ),
                  ),

                  Container(
                    width: 215,
                    height: 2.5,
                    color: Color(0xFF373A40),
                  ),

                  const SizedBox(height: 20),

                  const Text(
                    "قم بالسحب  لترتيب أنشطتك من الأكثر تفضيلاً إلى الأقل تفضيلاً",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFFC65600),
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    "الأكثر تفضيلاً",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF373A40),
                    ),
                  ),

                  Expanded(
                    child: ReorderableListView(
                      onReorder: (int oldIndex, int newIndex) {
                        setState(() {
                          if (newIndex > oldIndex) {
                            newIndex -= 1;
                          }
                          final item = _prioritizedActivities.removeAt(oldIndex);
                          _prioritizedActivities.insert(newIndex, item);
                        });
                      },
                      children: _prioritizedActivities.map((activity) {
                        return Card(
                          key: ValueKey(activity),
                          child: ListTile(
                            title: Text(activity, textAlign: TextAlign.right),
                            trailing: const Image(
                              image: AssetImage('assets/images/Vector.png'),
                              width: 24, // You can adjust the width as needed
                              height: 24, // You can adjust the height as needed
                            ),

                          ),
                        );
                      }).toList(),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    "الأقل تفضيلاً",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF373A40),
                    ),
                  ),
                  const SizedBox(height: 20),

                  GestureDetector(
                    onTap: () async {
                      final userId = FirebaseAuth.instance.currentUser?.uid;
                      if (userId == null) return;

                      final activatesCollection = FirebaseFirestore.instance
                          .collection('Patient')
                          .doc(userId)
                          .collection('Activates');

                      // 🛠️ تحديث كل نشاط مع أولويته
                      for (int i = 0; i < _prioritizedActivities.length; i++) {
                        final activityName = _prioritizedActivities[i];

                        // نبحث عن النشاط باستخدام ActivityName
                        final querySnapshot = await activatesCollection
                            .where('ActivityName', isEqualTo: activityName)
                            .limit(1)
                            .get();

                        if (querySnapshot.docs.isNotEmpty) {
                          // موجود: نحدث الأولوية
                          final docRef = querySnapshot.docs.first.reference;
                          await docRef.update({
                            'Priority': i + 1,
                          });
                        } else {
                          print('⚠️ النشاط $activityName غير موجود في فايرستور، لم يتم تحديثه.');
                        }

                      }

                      // ✅ بعد الحفظ، عرض رسالة نجاح
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text("✅ تم حفظ ترتيب الأنشطة بنجاح!"),
                          backgroundColor: Colors.green,
                        ),
                      );

                      // ✅ والانتقال لصفحة تحديد الأوقات
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => FreeTimeSelectionScreen()),
                      );
                    },
                    child: const ContinueButton(), // Wrapping ContinueButton inside GestureDetector
                  ),

                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
